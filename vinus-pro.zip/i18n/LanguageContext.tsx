import React, { createContext, useState, useEffect, useCallback } from 'react';

interface LanguageContextType {
  language: string;
  setLanguage: (language: string) => void;
  t: (key: string, options?: Record<string, string | number>) => string;
}

export const LanguageContext = createContext<LanguageContextType>({
  language: 'en',
  setLanguage: () => {},
  t: (key) => key,
});

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('vinus_pro_lang') || 'en';
  });
  const [translations, setTranslations] = useState<Record<string, any>>({});

  useEffect(() => {
    const loadTranslations = async () => {
      try {
        const response = await fetch(`/i18n/locales/${language}.json`);
        if (!response.ok) {
          throw new Error(`Could not load ${language}.json`);
        }
        const data = await response.json();
        setTranslations(data);
        localStorage.setItem('vinus_pro_lang', language);
        document.documentElement.lang = language;
      } catch (error) {
        console.error('Failed to load translations:', error);
        if (language !== 'en') {
            setLanguage('en');
        }
      }
    };
    loadTranslations();
  }, [language]);

  const t = useCallback((key: string, options?: Record<string, string | number>): string => {
    const keys = key.split('.');
    let result = keys.reduce((acc, currentKey) => {
        return acc && typeof acc === 'object' ? acc[currentKey] : undefined;
    }, translations);
    
    if (typeof result === 'string' && options) {
        Object.keys(options).forEach(optionKey => {
            const regex = new RegExp(`{{${optionKey}}}`, 'g');
            result = result.replace(regex, String(options[optionKey]));
        });
    }

    return typeof result === 'string' ? result : key;
  }, [translations]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};
