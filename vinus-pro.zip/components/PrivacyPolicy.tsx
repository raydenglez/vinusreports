import React from 'react';

interface PolicyProps {
    onBackToHome: () => void;
}

const PrivacyPolicy: React.FC<PolicyProps> = ({ onBackToHome }) => {
    return (
        <div className="bg-white p-8 rounded-xl shadow-lg max-w-4xl mx-auto animate-fade-in">
            <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
            <div className="prose max-w-none text-gray-700 space-y-4">
                <p><strong>Last Updated: {new Date().toLocaleDateString()}</strong></p>
                <p>Your privacy is important to us. It is VinUS Pro's policy to respect your privacy regarding any information we may collect from you across our website.</p>
                
                <h2 className="text-xl font-bold mt-6">1. Information We Collect</h2>
                <p>We only ask for personal information when we truly need it to provide a service to you. We collect it by fair and lawful means, with your knowledge and consent. We also let you know why we’re collecting it and how it will be used.</p>
                
                <h2 className="text-xl font-bold mt-6">2. How We Use Your Information</h2>
                <p>We use the information we collect to operate, maintain, and provide the features and functionality of the VinUS Pro service. For dealer accounts, this includes managing your subscription, processing payments, and providing access to your report history.</p>

                <h2 className="text-xl font-bold mt-6">3. Security</h2>
                <p>We take security seriously. All payment information is handled securely by our payment processor, Square, Inc. We do not store your full credit card information on our servers.</p>
                
                <h2 className="text-xl font-bold mt-6">4. Cookies</h2>
                <p>We use cookies to store information about your session and preferences. Cookies are small data files stored on your hard drive or in device memory that help us improve our services and your experience.</p>

                <h2 className="text-xl font-bold mt-6">5. Changes to This Policy</h2>
                <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.</p>
            </div>
            <button onClick={onBackToHome} className="mt-8 px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700">
                &larr; Back to Home
            </button>
        </div>
    );
};

export default PrivacyPolicy;