import React, { useState, useCallback } from 'react';
import type { SelectedPlan } from '../../types';
import SquarePaymentForm from './SquarePaymentForm';
import { CheckCircleIcon } from '../icons/Icons';
import { useTranslation } from '../../i18n/useTranslation';

interface CheckoutPageProps {
    plan: SelectedPlan;
    onBack: () => void;
}

const CheckoutPage: React.FC<CheckoutPageProps> = ({ plan, onBack }) => {
    const { t } = useTranslation();
    const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
    const [errorMessage, setErrorMessage] = useState('');
    
    const handlePaymentError = useCallback((error: string) => {
        setPaymentStatus('error');
        setErrorMessage(error);
    }, []);

    const handlePaymentSuccess = useCallback(async (token: string) => {
        console.log('Payment Token Received:', token);
        setPaymentStatus('processing');
        
        try {
            // This is a mock API call. In a real application, you would send the
            // token to your backend server to process the payment.
            const response = await new Promise(resolve => setTimeout(() => resolve({ ok: true }), 2000));

            if ((response as any).ok) {
                setPaymentStatus('success');
            } else {
                throw new Error('Payment failed on the server.');
            }
        } catch (error) {
            if (error instanceof Error) {
                handlePaymentError(error.message);
            } else {
                handlePaymentError('An unknown error occurred during payment processing.');
            }
        }
    }, [handlePaymentError]);

    if (paymentStatus === 'success') {
        return (
            <div className="max-w-2xl mx-auto text-center py-12 animate-fade-in">
                 <CheckCircleIcon className="h-16 w-16 text-green-500 mx-auto" />
                 <h1 className="mt-4 text-3xl font-bold text-gray-900">{t('checkout.successTitle')}</h1>
                 <p className="mt-2 text-gray-600" dangerouslySetInnerHTML={{ __html: t('checkout.successMessage', { planName: plan.name, cycle: plan.billingCycle }) }} />
                 <button onClick={onBack} className="mt-8 px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700">
                    {t('checkout.backToHome')}
                </button>
            </div>
        )
    }

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <button onClick={onBack} className="mb-6 text-sm text-blue-600 hover:underline">
                {t('checkout.backToPlans')}
            </button>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
                <div className="bg-white p-8 rounded-xl shadow-lg border">
                    <h2 className="text-2xl font-bold text-gray-800 border-b pb-4">{t('checkout.orderSummary')}</h2>
                    <div className="mt-6 space-y-4">
                        <div className="flex justify-between">
                            <span className="text-gray-600">{plan.name} ({plan.billingCycle})</span>
                            <span className="font-semibold">${plan.price.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-gray-600">
                            <span>{t('checkout.taxesAndFees')}</span>
                            <span className="font-semibold">{t('checkout.calculatedNextStep')}</span>
                        </div>
                    </div>
                    <div className="mt-6 pt-4 border-t-2 border-dashed">
                        <div className="flex justify-between font-bold text-xl">
                            <span>{t('checkout.total')}</span>
                            <span>${plan.price.toFixed(2)}</span>
                        </div>
                    </div>
                    <ul className="mt-8 space-y-3 text-sm text-gray-600">
                        {plan.features.slice(0, 4).map(feature => (
                           <li key={feature} className="flex items-center">
                               <CheckCircleIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                               <span>{feature}</span>
                           </li>
                        ))}
                    </ul>
                </div>

                <div className="bg-white p-8 rounded-xl shadow-lg border">
                     <h2 className="text-2xl font-bold text-gray-800 mb-6">{t('checkout.paymentDetails')}</h2>
                     <SquarePaymentForm
                        onSuccess={handlePaymentSuccess}
                        onError={handlePaymentError}
                        setStatus={setPaymentStatus}
                        price={plan.price}
                     />
                     {paymentStatus === 'error' && (
                         <p className="mt-4 text-sm text-red-600">{errorMessage}</p>
                     )}
                </div>
            </div>
        </div>
    );
};

export default CheckoutPage;