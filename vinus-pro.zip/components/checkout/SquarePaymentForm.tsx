import React, { useEffect, useState, useRef } from 'react';
import { CreditCardIcon, LockClosedIcon } from '../icons/Icons';
import { useTranslation } from '../../i18n/useTranslation';

declare global {
  interface Window {
    Square: any;
  }
}

interface SquarePaymentFormProps {
    onSuccess: (token: string) => void;
    onError: (error: string) => void;
    setStatus: (status: 'idle' | 'processing' | 'success' | 'error') => void;
    price: number;
}

const SquarePaymentForm: React.FC<SquarePaymentFormProps> = ({ onSuccess, onError, setStatus, price }) => {
    const { t } = useTranslation();
    const [card, setCard] = useState<any>(null);
    const formRef = useRef<HTMLFormElement>(null);
    const [isSecureContext, setIsSecureContext] = useState(true);

    useEffect(() => {
        const isSecure = window.isSecureContext;
        setIsSecureContext(isSecure);

        if (!isSecure) {
            console.warn('Square Payments SDK requires a secure (HTTPS) context and will not be initialized.');
            return;
        }

        const initializeSquare = async () => {
            if (!window.Square) {
                onError('Payment provider failed to initialize correctly.');
                return;
            }
            
            const SQUARE_APP_ID = 'sandbox-sq0idb-gHLNXakieAOmx_37xY5dtA';
            const SQUARE_LOCATION_ID = 'L9FZ4PXJ0DG12';
            
            const payments = window.Square.payments(SQUARE_APP_ID, SQUARE_LOCATION_ID);
            try {
                const cardInstance = await payments.card();
                await cardInstance.attach('#card-container');
                setCard(cardInstance);
            } catch (e: any) {
                if (e.message && e.message.includes('already attached')) {
                    console.warn('Square card form already attached.');
                    return;
                }
                console.error('Initializing card failed', e);
                onError('Could not initialize payment form.');
            }
        };

        if (window.Square) {
            initializeSquare();
        } else {
            const script = document.createElement('script');
            script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
            script.type = 'text/javascript';
            script.async = true;
            script.onload = initializeSquare;
            script.onerror = () => {
                console.error('Square SDK script failed to load.');
                onError('Payment provider failed to load. Please refresh the page.');
            };
            document.body.appendChild(script);
        }
    }, [onError]);

    const handlePayment = async (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
        if (!card) {
            onError('Payment form is not ready.');
            return;
        }
        
        setStatus('processing');

        try {
            const result = await card.tokenize();
            if (result.status === 'OK' && result.token) {
                console.log(`Payment token is ${result.token}`);
                onSuccess(result.token);
            } else {
                setStatus('error');
                let errorMessage = `Tokenization failed with status: ${result.status}`;
                if (result.errors) {
                    errorMessage += ` and errors: ${JSON.stringify(result.errors)}`;
                    onError(result.errors.map((e: any) => e.message).join(' '));
                } else {
                    onError('An unexpected error occurred during payment processing.');
                }
                console.error(errorMessage);
            }
        } catch (e: any) {
            console.error(e);
            setStatus('error');
            onError(e.message);
        }
    };

    if (!isSecureContext) {
        return (
            <div className="text-center p-4 border-2 border-dashed border-red-300 bg-red-50 rounded-lg">
                <LockClosedIcon className="h-8 w-8 mx-auto text-red-500" />
                <p className="mt-2 text-red-700 font-semibold">{t('checkout.httpsRequiredTitle')}</p>
                <p className="text-sm text-red-600 mt-1">{t('checkout.httpsRequiredBody')}</p>
            </div>
        );
    }

    return (
        <form ref={formRef} className="space-y-4">
            <div id="card-container"></div>
            <button
                type="submit"
                onClick={handlePayment}
                disabled={!card}
                className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300 disabled:cursor-not-allowed"
            >
                <CreditCardIcon className="h-5 w-5 mr-2" />
                {t('checkout.payButton', { price: price.toFixed(2) })}
            </button>
            <p className="text-xs text-center text-gray-500 mt-2">
                {t('checkout.securePayments')}
            </p>
        </form>
    );
};

export default SquarePaymentForm;