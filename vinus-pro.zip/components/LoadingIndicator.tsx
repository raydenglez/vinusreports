import React, { useState, useEffect } from 'react';
import { useTranslation } from '../i18n/useTranslation';

const LoadingIndicator: React.FC = () => {
  const { t } = useTranslation();
  const [messageIndex, setMessageIndex] = useState(0);

  const messages = t('loadingIndicator.messages').split('\n');

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex(prevIndex => (prevIndex + 1));
    }, 1500);

    if (messageIndex >= messages.length - 1) {
        clearInterval(interval);
    }

    return () => clearInterval(interval);
  }, [messageIndex, messages.length]);

  return (
    <div className="text-center p-10 flex flex-col items-center justify-center animate-fade-in">
      <div className="relative h-20 w-20">
        <div className="absolute inset-0 rounded-full border-4 border-gray-200"></div>
        <div className="absolute inset-0 rounded-full border-t-4 border-blue-600 animate-spin"></div>
      </div>
      <h2 className="mt-6 text-2xl font-bold text-gray-800">{t('loadingIndicator.title')}</h2>
      <p className="mt-2 text-lg text-gray-600 transition-opacity duration-500 h-6">
        {messages[messageIndex] || messages[messages.length - 1]}
      </p>
    </div>
  );
};

export default LoadingIndicator;
