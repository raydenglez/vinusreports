import React from 'react';
import type { VehicleSpecs } from '../types';
import { numberFormatter } from '../utils/formatters';
import { useTranslation } from '../i18n/useTranslation';

interface VehicleSpecificationsProps {
  specs: VehicleSpecs;
  fuelType: string;
}

const SpecItem: React.FC<{ label: string; value: string | number }> = ({ label, value }) => (
  <div className="flex justify-between py-2 border-b border-gray-100">
    <span className="text-sm text-gray-600">{label}</span>
    <span className="text-sm font-semibold text-gray-800">{value}</span>
  </div>
);

const VehicleSpecifications: React.FC<VehicleSpecificationsProps> = ({ specs, fuelType }) => {
  const { t } = useTranslation();
  const isElectric = fuelType.toLowerCase() === 'electric';

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-bold mb-4">{t('reportSections.specifications')}</h3>
      <div className="space-y-1">
        <SpecItem label={isElectric ? t('specifications.cityMPGe') : t('specifications.cityMPG')} value={numberFormatter.format(specs.mpg_city)} />
        <SpecItem label={isElectric ? t('specifications.highwayMPGe') : t('specifications.highwayMPG')} value={numberFormatter.format(specs.mpg_highway)} />
        <SpecItem label={t('specifications.horsepower')} value={numberFormatter.format(specs.horsepower)} />
        <SpecItem label={t('specifications.torque')} value={numberFormatter.format(specs.torque_ft_lbs)} />
        <SpecItem label={t('specifications.weight')} value={numberFormatter.format(specs.curb_weight_lbs)} />
        <SpecItem label={t('specifications.length')} value={specs.length_in} />
        <SpecItem label={t('specifications.width')} value={specs.width_in} />
        <SpecItem label={t('specifications.height')} value={specs.height_in} />
      </div>
    </div>
  );
};

export default VehicleSpecifications;
