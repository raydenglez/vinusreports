import React from 'react';
import { LockClosedIcon } from './icons/Icons';
import { useTranslation } from '../i18n/useTranslation';

interface UnlockOverlayProps {
  onUnlock: () => void;
  onSubscribe: () => void;
}

const UnlockOverlay: React.FC<UnlockOverlayProps> = ({ onUnlock, onSubscribe }) => {
  const { t } = useTranslation();
  
  return (
    <div className="absolute inset-0 bg-gray-900 bg-opacity-60 flex flex-col items-center justify-center z-10 p-4 text-center">
      <div className="bg-white p-8 rounded-xl shadow-2xl max-w-sm w-full">
        <LockClosedIcon className="h-12 w-12 text-blue-500 mx-auto" />
        <h3 className="mt-4 text-2xl font-bold text-gray-900">{t('unlockOverlay.title')}</h3>
        <p className="mt-2 text-gray-600">
          {t('unlockOverlay.text')}
        </p>
        <div className="mt-6 space-y-4">
          <button
            onClick={onUnlock}
            className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors"
          >
            {t('unlockOverlay.buyButton')}
          </button>
          <button
            onClick={onSubscribe}
            className="w-full bg-gray-100 text-blue-600 font-bold py-3 px-6 rounded-lg hover:bg-gray-200 transition-colors"
          >
            {t('unlockOverlay.subscribeButton')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default UnlockOverlay;
