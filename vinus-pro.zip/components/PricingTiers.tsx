import React, { useState } from 'react';
import type { SelectedPlan, BillingCycle } from '../types';
import { CheckIcon, XCircleIcon } from './icons/Icons';
import { useTranslation } from '../i18n/useTranslation';

export const plans = [
    {
        id: 'free',
        name: 'pricingTiers.freeName',
        description: 'pricingTiers.freeDesc',
        features: [
            'pricingTiers.freeFeature1',
            'pricingTiers.freeFeature2',
        ],
        excludedFeatures: [
            'pricingTiers.freeExcluded1',
            'pricingTiers.freeExcluded2',
            'pricingTiers.freeExcluded3',
            'pricingTiers.freeExcluded4',
            'pricingTiers.freeExcluded5',
        ],
        price: 0,
        cta: 'pricingTiers.freeCta',
    },
    {
        id: 'pay-as-you-go',
        name: 'pricingTiers.paygName',
        description: 'pricingTiers.paygDesc',
        features: [
            'pricingTiers.paygFeature1',
            'pricingTiers.paygFeature2',
            'pricingTiers.paygFeature3',
            'pricingTiers.paygFeature4',
            'pricingTiers.paygFeature5',
            'pricingTiers.paygFeature6',
        ],
        price: 2.99,
        cta: 'pricingTiers.paygCta',
    },
    {
        id: 'pro',
        name: 'pricingTiers.proName',
        description: 'pricingTiers.proDesc',
        features: [
            'pricingTiers.proFeature1',
            'pricingTiers.proFeature2',
            'pricingTiers.proFeature3',
            'pricingTiers.proFeature4',
            'pricingTiers.proFeature5',
            'pricingTiers.proFeature6',
        ],
        monthlyPrice: 39,
        yearlyPrice: 390,
        cta: 'pricingTiers.proCta',
        highlight: true,
    },
];

interface PricingTiersProps {
    onSelectPlan: (plan: SelectedPlan) => void;
}

const PricingTiers: React.FC<PricingTiersProps> = ({ onSelectPlan }) => {
    const { t } = useTranslation();
    const [billingCycle, setBillingCycle] = useState<BillingCycle>('monthly');
    
    const handleSelectPlan = (plan: typeof plans[0], cycle: BillingCycle) => {
        let price: number | 'Custom' = 0;
        let priceSuffix = '';
        const translatedFeatures = plan.features.map(f => t(f));

        if (plan.id === 'pay-as-you-go') {
            if (typeof plan.price === 'number') {
                price = plan.price;
            }
            priceSuffix = t('pricingTiers.priceSuffixReport');
        } else if (plan.id === 'pro') {
            if (cycle === 'monthly') {
                price = plan.monthlyPrice;
                priceSuffix = t('pricingTiers.priceSuffixMonth');
            } else {
                price = plan.yearlyPrice;
                priceSuffix = t('pricingTiers.priceSuffixYear');
            }
        }
        
        if (typeof price !== 'number') return;

        onSelectPlan({
            name: t(plan.name),
            price: price,
            billingCycle: cycle,
            priceSuffix: priceSuffix,
            features: translatedFeatures
        });
    }

    return (
        <div className="max-w-5xl mx-auto">
            <div className="flex justify-center mb-8">
                <div className="relative flex p-1 bg-gray-200 rounded-full">
                    <button
                        onClick={() => setBillingCycle('monthly')}
                        className={`relative w-28 h-10 rounded-full transition-colors duration-300 focus:outline-none ${billingCycle === 'monthly' ? 'text-white' : 'text-gray-600'}`}
                    >
                        {t('pricingTiers.monthly')}
                    </button>
                    <button
                        onClick={() => setBillingCycle('yearly')}
                        className={`relative w-28 h-10 rounded-full transition-colors duration-300 focus:outline-none ${billingCycle === 'yearly' ? 'text-white' : 'text-gray-600'}`}
                    >
                        {t('pricingTiers.yearly')}
                    </button>
                    <span
                        className={`absolute top-1 left-1 h-10 w-28 bg-blue-600 rounded-full shadow-md transform transition-transform duration-300 ease-in-out ${billingCycle === 'yearly' ? 'translate-x-full' : ''}`}
                        aria-hidden="true"
                    />
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {plans.map((tier) => {
                    const isPro = tier.id === 'pro';
                    const isFree = tier.id === 'free';
                    const price = isPro ? (billingCycle === 'monthly' ? tier.monthlyPrice : tier.yearlyPrice) : tier.price;
                    const priceSuffixKey = isPro ? (billingCycle === 'monthly' ? 'pricingTiers.priceSuffixMonth' : 'pricingTiers.priceSuffixYear') : (tier.id === 'pay-as-you-go' ? 'pricingTiers.priceSuffixReport' : '');
                    const priceSuffix = priceSuffixKey ? t(priceSuffixKey) : '';
                    const monthlyPriceForYearly = isPro ? (tier.yearlyPrice / 12).toFixed(2) : null;

                    return (
                        <div key={tier.id} className={`bg-white rounded-xl shadow-lg p-8 flex flex-col ${tier.highlight ? 'border-2 border-blue-600' : 'border'}`}>
                             {tier.highlight && (
                                <div className="relative h-6">
                                    <span className="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full absolute -top-12 self-center">{t('pricingTiers.mostPopular')}</span>
                                    {billingCycle === 'yearly' && <span className="bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full absolute -top-4 right-0">{t('pricingTiers.save')}</span>}
                                </div>
                             )}
                            <h3 className="text-2xl font-bold">{t(tier.name)}</h3>
                            <p className="mt-4 text-gray-600 flex-grow">{t(tier.description)}</p>
                            <div className="mt-6">
                                <span className="text-4xl font-extrabold">{typeof price === 'number' ? (price === 0 ? t('pricingTiers.freeName') : `$${price}`) : price}</span>
                                <span className="text-base font-medium text-gray-500">{priceSuffix}</span>
                                {isPro && billingCycle === 'yearly' && <p className="text-sm text-gray-500 mt-1">{t('pricingTiers.billedAnnually', { price: monthlyPriceForYearly })}</p>}
                            </div>
                            <ul className="mt-8 space-y-4">
                                {tier.features.map((feature) => (
                                    <li key={feature} className="flex items-start">
                                        <CheckIcon className="flex-shrink-0 h-6 w-6 text-green-500" />
                                        <span className="ml-3 text-gray-700">{t(feature)}</span>
                                    </li>
                                ))}
                                {(tier as any).excludedFeatures?.map((feature: string) => (
                                    <li key={feature} className="flex items-start">
                                        <XCircleIcon className="flex-shrink-0 h-6 w-6 text-gray-400" />
                                        <span className="ml-3 text-gray-500 line-through">{t(feature)}</span>
                                    </li>
                                ))}
                            </ul>
                            <button
                                onClick={() => handleSelectPlan(tier, billingCycle)}
                                className={`mt-auto w-full py-3 px-6 text-lg font-semibold rounded-lg transition-colors duration-300 ${tier.highlight ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-gray-100 text-blue-600 hover:bg-gray-200'} disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed`}
                                disabled={isFree}
                            >
                                {t(tier.cta)}
                            </button>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default PricingTiers;
