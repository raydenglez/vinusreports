import React, { useState } from 'react';
import VinInput from './VinInput';
import PricingTiers from './PricingTiers';
import type { SelectedPlan } from '../types';
import { CheckCircleIcon, ShieldCheckIcon, DocumentReportIcon, LightningBoltIcon } from './icons/Icons';
import Modal from './Modal';
import VinScanner from './VinScanner';
import { useTranslation } from '../i18n/useTranslation';

interface LandingPageProps {
  onSearch: (vin: string) => void;
  isLoading: boolean;
  error: string | null;
  exampleVins: { vin: string, name: string }[];
  onSelectPlan: (plan: SelectedPlan) => void;
  activeReport?: React.ReactNode;
}

const LandingPage: React.FC<LandingPageProps> = ({ onSearch, isLoading, error, exampleVins, onSelectPlan, activeReport }) => {
  const { t } = useTranslation();
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  
  return (
    <div className="space-y-16">
      <Modal 
        isOpen={isScannerOpen} 
        onClose={() => setIsScannerOpen(false)}
        title={t('vinScanner.modalTitle')}
      >
        <VinScanner onSearch={onSearch} onClose={() => setIsScannerOpen(false)} />
      </Modal>

      <section className="text-center pt-16 pb-12">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-gray-900 tracking-tight">
          {t('landingPage.heroTitle')}
        </h1>
        <p className="mt-4 max-w-3xl mx-auto text-lg sm:text-xl text-gray-600">
          {t('landingPage.heroSubtitle')}
        </p>
        <div className="mt-8 max-w-2xl mx-auto">
          <VinInput 
            onSearch={onSearch} 
            isLoading={isLoading} 
            exampleVins={exampleVins}
            onScannerClick={() => setIsScannerOpen(true)}
          />
          {error && <p className="mt-4 text-red-600 font-semibold">{error}</p>}
        </div>
      </section>

      {activeReport && <section id="report-preview">{activeReport}</section>}
      
      <section id="features" className="py-12 bg-white rounded-xl shadow-md">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center">{t('landingPage.featuresTitle')}</h2>
          <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-10">
            <div className="flex">
              <div className="flex-shrink-0"><ShieldCheckIcon className="h-8 w-8 text-green-500" /></div>
              <div className="ml-4">
                <h3 className="text-lg font-medium">{t('landingPage.feature1Title')}</h3>
                <p className="mt-2 text-gray-600">{t('landingPage.feature1Text')}</p>
              </div>
            </div>
            <div className="flex">
              <div className="flex-shrink-0"><DocumentReportIcon className="h-8 w-8 text-blue-500" /></div>
              <div className="ml-4">
                <h3 className="text-lg font-medium">{t('landingPage.feature2Title')}</h3>
                <p className="mt-2 text-gray-600">{t('landingPage.feature2Text')}</p>
              </div>
            </div>
            <div className="flex">
              <div className="flex-shrink-0"><LightningBoltIcon className="h-8 w-8 text-yellow-500" /></div>
              <div className="ml-4">
                <h3 className="text-lg font-medium">{t('landingPage.feature3Title')}</h3>
                <p className="mt-2 text-gray-600">{t('landingPage.feature3Text')}</p>
              </div>
            </div>
            <div className="flex">
              <div className="flex-shrink-0"><CheckCircleIcon className="h-8 w-8 text-red-500" /></div>
              <div className="ml-4">
                <h3 className="text-lg font-medium">{t('landingPage.feature4Title')}</h3>
                <p className="mt-2 text-gray-600">{t('landingPage.feature4Text')}</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <section id="pricing" className="py-12">
          <h2 className="text-3xl font-bold text-center mb-10">{t('landingPage.pricingTitle')}</h2>
          <PricingTiers onSelectPlan={onSelectPlan} />
      </section>
    </div>
  );
};

export default LandingPage;
