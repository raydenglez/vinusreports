import React, { useState } from 'react';
import { useTranslation } from '../i18n/useTranslation';

interface ForgotPasswordPageProps {
    onRequestReset: (email: string) => void;
    onBackToLogin: () => void;
}

const ForgotPasswordPage: React.FC<ForgotPasswordPageProps> = ({ onRequestReset, onBackToLogin }) => {
    const { t } = useTranslation();
    const [email, setEmail] = useState('');
    const [isSubmitted, setIsSubmitted] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitted(true);
        setTimeout(() => {
            onRequestReset(email);
        }, 2500);
    }

    return (
        <div className="flex flex-col items-center justify-center py-12 animate-fade-in">
            <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-lg">
                <div className="text-center">
                    <h2 className="text-3xl font-bold text-gray-800">{t('forgotPasswordPage.title')}</h2>
                    {!isSubmitted ? (
                        <p className="mt-2 text-gray-600">{t('forgotPasswordPage.subtitle')}</p>
                    ) : (
                         <p className="mt-2 text-green-700">{t('forgotPasswordPage.submitted')}</p>
                    )}
                </div>
                {!isSubmitted && (
                    <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
                        <div>
                            <label htmlFor="email-address-forgot" className="sr-only">{t('loginPage.emailPlaceholder')}</label>
                            <input
                                id="email-address-forgot"
                                name="email"
                                type="email"
                                autoComplete="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="appearance-none rounded-md relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                placeholder={t('loginPage.emailPlaceholder')}
                            />
                        </div>
                        <div>
                            <button
                                type="submit"
                                className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                            >
                                {t('forgotPasswordPage.sendLink')}
                            </button>
                        </div>
                    </form>
                )}
                 <div className="mt-4 text-center text-sm">
                    <button onClick={onBackToLogin} className="font-medium text-blue-600 hover:text-blue-500">
                        {t('forgotPasswordPage.backToSignIn')}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ForgotPasswordPage;
