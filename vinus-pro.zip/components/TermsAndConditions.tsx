import React from 'react';

interface PolicyProps {
    onBackToHome: () => void;
}

const TermsAndConditions: React.FC<PolicyProps> = ({ onBackToHome }) => {
    return (
        <div className="bg-white p-8 rounded-xl shadow-lg max-w-4xl mx-auto animate-fade-in">
            <h1 className="text-3xl font-bold mb-6">Terms and Conditions</h1>
            <div className="prose max-w-none text-gray-700 space-y-4">
                <p><strong>Last Updated: {new Date().toLocaleDateString()}</strong></p>
                <p>By accessing this website, you are agreeing to be bound by these terms of service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws.</p>

                <h2 className="text-xl font-bold mt-6">1. Use License</h2>
                <p>Permission is granted to temporarily download one copy of the materials on VinUS Pro's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title.</p>
                
                <h2 className="text-xl font-bold mt-6">2. Disclaimer</h2>
                <p>The materials on VinUS Pro's website are provided on an 'as is' basis. VinUS Pro makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
                <p>The information provided in vehicle history reports is aggregated from various third-party data sources. VinUS Pro does not guarantee the accuracy, completeness, or timeliness of this information. The reports should not be used as a substitute for a physical vehicle inspection by a qualified mechanic.</p>
                
                <h2 className="text-xl font-bold mt-6">3. Limitations</h2>
                <p>In no event shall VinUS Pro or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on VinUS Pro's website.</p>
                
                <h2 className="text-xl font-bold mt-6">4. Governing Law</h2>
                <p>These terms and conditions are governed by and construed in accordance with the laws of the United States and you irrevocably submit to the exclusive jurisdiction of the courts in that State or location.</p>
            </div>
            <button onClick={onBackToHome} className="mt-8 px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700">
                &larr; Back to Home
            </button>
        </div>
    );
};

export default TermsAndConditions;