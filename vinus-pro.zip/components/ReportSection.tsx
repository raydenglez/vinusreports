

import React from 'react';

interface Column<T> {
    header: string;
    key: keyof T;
    render?: (item: T) => React.ReactNode;
    className?: string;
}

interface ReportSectionProps<T> {
    title: string;
    items: T[];
    columns?: Column<T>[];
    renderItem?: (item: T) => React.ReactNode;
    emptyText?: string;
}

const ReportSection = <T extends object>(props: ReportSectionProps<T>) => {
    const { title, items, columns, renderItem, emptyText = "No data available for this section." } = props;

    return (
        <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="p-6 border-b">
                <h3 className="text-xl font-bold">{title}</h3>
            </div>
            
            {items.length === 0 ? (
                <p className="p-6 text-gray-500">{emptyText}</p>
            ) : (
                <div>
                    {renderItem ? (
                        items.map((item, index) => <div key={index}>{renderItem(item)}</div>)
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead className="bg-gray-50">
                                    <tr>
                                        {columns?.map((col) => (
                                            <th key={String(col.key)} scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                {col.header}
                                            </th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {items.map((item, index) => (
                                        <tr key={index}>
                                            {columns?.map((col) => (
                                                <td key={String(col.key)} className={`px-6 py-4 whitespace-nowrap text-sm text-gray-700 ${col.className || ''}`}>
                                                    {col.render ? col.render(item) : String(item[col.key])}
                                                </td>
                                            ))}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default ReportSection;