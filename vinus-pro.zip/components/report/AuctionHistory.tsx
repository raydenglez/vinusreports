import React from 'react';
import type { AuctionRecord } from '../../types';
import { currencyFormatter, numberFormatter } from '../../utils/formatters';
import { AuctionIcon } from '../icons/Icons';
import ReportSection from '../ReportSection';
import { useTranslation } from '../../i18n/useTranslation';

interface AuctionHistoryProps {
    records: AuctionRecord[];
}

const AuctionHistory: React.FC<AuctionHistoryProps> = ({ records }) => {
    const { t } = useTranslation();

    if (records.length === 0) {
        return (
            <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex items-center mb-4">
                    <AuctionIcon className="h-6 w-6 mr-3 text-blue-600"/>
                    <h3 className="text-xl font-bold">{t('reportSections.auctionHistory')}</h3>
                </div>
                <p className="text-gray-500">{t('premiumData.auctionHistory')}</p>
            </div>
        );
    }

    return (
        <ReportSection<AuctionRecord>
            title={t('reportSections.auctionHistory')}
            items={records}
            columns={[
                { header: t('tableHeaders.date'), key: 'date', render: item => new Date(item.date).toLocaleDateString() },
                { header: t('tableHeaders.auction'), key: 'source', render: item => (
                    <div>
                        <p className="font-bold">{item.source}</p>
                        <p className="text-xs text-gray-500">{item.location}</p>
                    </div>
                )},
                { header: t('tableHeaders.odometer'), key: 'odometer', render: item => `${numberFormatter.format(item.odometer)} mi` },
                { header: t('tableHeaders.titleType'), key: 'title_type' },
                { header: t('tableHeaders.hammerPrice'), key: 'hammer_price', render: item => item.hammer_price === 'N/A' ? 'N/A' : currencyFormatter.format(item.hammer_price) },
                { header: t('tableHeaders.source'), key: 'source_url', render: item => (
                    <a href={item.source_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                        {t('tableHeaders.view')}
                    </a>
                )},
            ]}
        />
    );
};

export default AuctionHistory;