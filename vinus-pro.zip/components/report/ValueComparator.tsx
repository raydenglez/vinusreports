import React, { useMemo } from 'react';
import type { VehicleReport } from '../../types';
import { ValueIcon } from '../icons/Icons';
import { currencyFormatter, numberFormatter } from '../../utils/formatters';
import { useTranslation } from '../../i18n/useTranslation';

interface ValueComparatorProps {
    report: VehicleReport;
}

const ValueComparator: React.FC<ValueComparatorProps> = ({ report }) => {
    const { t } = useTranslation();

    const avgMarketPrice = useMemo(() => {
        if (!report.liveMarketListings || report.liveMarketListings.length === 0) {
            return report.marketValuation.retail;
        }
        const total = report.liveMarketListings.reduce((sum, listing) => sum + listing.price, 0);
        return total / report.liveMarketListings.length;
    }, [report.liveMarketListings, report.marketValuation.retail]);

    const aiValuation = useMemo(() => {
        let baseValue = avgMarketPrice;
        const reasons: string[] = [];
        
        if (report.accidents.length > 0) {
            baseValue *= 0.85;
            reasons.push(t('valueComparator.reasons.accidents'));
        }
        if (report.titlesAndBrands.some(t => /salvage|rebuilt/i.test(t.brand))) {
            baseValue *= 0.7;
            reasons.push(t('valueComparator.reasons.title'));
        }
        if (report.odometerEvents.some(o => o.flagged_rollback)) {
            baseValue *= 0.8;
            reasons.push(t('valueComparator.reasons.odometer'));
        }
        
        const finalValue = baseValue;
        const range = [finalValue * 0.95, finalValue * 1.05];
        
        let explanation = t('valueComparator.aiExplanationBase', { price: currencyFormatter.format(avgMarketPrice) });
        if (reasons.length > 0) {
            explanation += ' ' + t('valueComparator.aiExplanationAdjusted', { reasons: reasons.join(', ') });
        }
        explanation += ' ' + t('valueComparator.aiExplanationRefined');

        return { range, explanation };
    }, [report, avgMarketPrice, t]);

    return (
        <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center mb-6">
                <ValueIcon className="h-6 w-6 mr-3 text-blue-600"/>
                <h3 className="text-xl font-bold">{t('reportSections.valueComparator')}</h3>
            </div>
            
            {/* Live Market Data Section */}
            <div className="mb-8">
                <h4 className="font-bold text-lg text-gray-800 mb-2">{t('valueComparator.liveMarketDataTitle')}</h4>
                <div className="bg-gray-50 p-4 rounded-lg flex items-center justify-between">
                    <div>
                        <p className="text-gray-600">{t('valueComparator.avgMarketPrice')}</p>
                        <p className="text-3xl font-extrabold text-gray-900">{currencyFormatter.format(avgMarketPrice)}</p>
                    </div>
                    <p className="text-sm text-gray-500">{t('valueComparator.basedOnListings', { count: report.liveMarketListings.length })}</p>
                </div>
                <div className="mt-4 overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-500 uppercase">
                             <tr>
                                <th className="p-2">{t('tableHeaders.listingSource')}</th>
                                <th className="p-2 text-right">{t('tableHeaders.price')}</th>
                                <th className="p-2 text-right">{t('tableHeaders.mileage')}</th>
                                <th className="p-2">{t('tableHeaders.location')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {report.liveMarketListings.map((listing, index) => (
                                <tr key={index} className="border-b">
                                    <td className="p-2"><a href={listing.url} target="_blank" rel="noopener noreferrer" className="font-semibold text-blue-600 hover:underline">{listing.source}</a></td>
                                    <td className="p-2 text-right font-medium">{currencyFormatter.format(listing.price)}</td>
                                    <td className="p-2 text-right">{numberFormatter.format(listing.mileage)}</td>
                                    <td className="p-2">{listing.location}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* AI Valuation */}
            <div className="mb-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h4 className="font-bold text-blue-800">{t('valueComparator.aiValuationTitle')}</h4>
                <p className="text-2xl font-extrabold text-blue-900 my-2">
                    {currencyFormatter.format(aiValuation.range[0])} - {currencyFormatter.format(aiValuation.range[1])}
                </p>
                <p className="text-xs text-blue-700">{aiValuation.explanation}</p>
            </div>
            
            {/* Traditional Valuation Guides */}
            <div>
                 <h4 className="font-bold text-lg text-gray-800 mb-2">{t('valueComparator.valuationGuidesTitle')}</h4>
                <table className="w-full text-sm text-left">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="p-2 font-semibold">{t('tableHeaders.source')}</th>
                            <th className="p-2 font-semibold text-right">{t('tableHeaders.retailValue')}</th>
                            <th className="p-2 font-semibold text-right">{t('tableHeaders.tradeInValue')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {report.valuationSources.map(source => (
                            <tr key={source.provider} className="border-b">
                                <td className="p-2 font-bold">{source.provider}</td>
                                <td className="p-2 text-right">{currencyFormatter.format(source.retail)}</td>
                                <td className="p-2 text-right">{currencyFormatter.format(source.trade_in)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

        </div>
    );
};

export default ValueComparator;
