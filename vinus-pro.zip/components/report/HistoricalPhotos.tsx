import React, { useState } from 'react';
import type { HistoricalPhoto } from '../../types';
import { PhotoIcon } from '../icons/Icons';
import Modal from '../Modal';
import { useTranslation } from '../../i18n/useTranslation';

interface HistoricalPhotosProps {
    photos: HistoricalPhoto[];
}

const HistoricalPhotos: React.FC<HistoricalPhotosProps> = ({ photos }) => {
    const { t } = useTranslation();
    const [showAll, setShowAll] = useState(false);
    const [selectedPhoto, setSelectedPhoto] = useState<HistoricalPhoto | null>(null);
    const initialVisibleCount = 4;

    if (photos.length === 0) {
        return null;
    }

    return (
        <>
            <Modal isOpen={!!selectedPhoto} onClose={() => setSelectedPhoto(null)} title={t('historicalPhotos.modalTitle')}>
                {selectedPhoto && (
                    <div>
                        <img src={selectedPhoto.url} alt={selectedPhoto.description} className="w-full h-auto rounded-lg object-contain max-h-[70vh]" />
                        <div className="mt-4 text-sm text-gray-700">
                            <p><strong>{t('historicalPhotos.source')}:</strong> {selectedPhoto.source}</p>
                            <p><strong>{t('historicalPhotos.date')}:</strong> {new Date(selectedPhoto.date).toLocaleDateString()}</p>
                            <p><strong>{t('historicalPhotos.description')}:</strong> {selectedPhoto.description}</p>
                        </div>
                    </div>
                )}
            </Modal>

            <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex items-center mb-4">
                    <PhotoIcon className="h-6 w-6 mr-3 text-blue-600"/>
                    <h3 className="text-xl font-bold">{t('reportSections.photos')}</h3>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {photos.map((photo, index) => {
                        const photoDate = new Date(photo.date).toLocaleDateString();
                        return (
                           <div 
                                key={index} 
                                onClick={() => setSelectedPhoto(photo)} 
                                className={`aspect-square bg-gray-100 rounded-lg overflow-hidden cursor-pointer group relative transform transition-transform hover:scale-105 ${!showAll && index >= initialVisibleCount ? 'hidden' : 'block'} print:block`}
                                role="button"
                                tabIndex={0}
                                onKeyDown={(e) => e.key === 'Enter' && setSelectedPhoto(photo)}
                                aria-label={t('historicalPhotos.viewAria', { source: photo.source, date: photoDate })}
                            >
                                <img src={photo.url} alt={photo.description} className="w-full h-full object-cover" />
                                 <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2 text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                    <p className="font-bold truncate">{photo.source}</p>
                                    <p>{photoDate}</p>
                                </div>
                            </div>
                        )
                    })}
                </div>

                {photos.length > initialVisibleCount && !showAll && (
                    <div className="text-center mt-6 print:hidden">
                        <button onClick={() => setShowAll(true)} className="bg-gray-100 text-blue-600 font-semibold py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors">
                            {t('historicalPhotos.viewMore', { count: photos.length - initialVisibleCount })}
                        </button>
                    </div>
                )}
            </div>
        </>
    );
};

export default HistoricalPhotos;