import React, { useState, FormEvent, useEffect } from 'react';
import { CameraIcon } from './icons/Icons';
import { useTranslation } from '../i18n/useTranslation';
import { validateVin } from '../utils/vinValidator';

interface VinInputProps {
  onSearch: (vin: string) => void;
  isLoading: boolean;
  exampleVins: { vin: string, name: string }[];
  onScannerClick: () => void;
}

const VinInput: React.FC<VinInputProps> = ({ onSearch, isLoading, exampleVins, onScannerClick }) => {
  const { t } = useTranslation();
  const [vin, setVin] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isTouched, setIsTouched] = useState(false);

  useEffect(() => {
    if (isTouched) {
      handleValidation(vin, false);
    }
  }, [vin, isTouched, t]);

  const handleValidation = (value: string, onSubmit: boolean): boolean => {
    if (!value && !onSubmit) {
      setValidationError(null);
      return false;
    }

    // Don't show "17 characters" error while user is typing
    if (!onSubmit && value.length !== 17) {
       const { isValid, messageKey } = validateVin(value.padEnd(17, 'A'));
       if (messageKey === 'vinValidator.invalidChars' || messageKey === 'vinValidator.nonAlphanumeric') {
         setValidationError(t(messageKey));
       } else {
         setValidationError(null);
       }
       return false;
    }

    const { isValid, messageKey, options } = validateVin(value);
    
    if (!isValid) {
      setValidationError(t(messageKey, options));
    } else {
      setValidationError(null);
    }
    return isValid;
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const upperVin = e.target.value.toUpperCase();
    setVin(upperVin);
  };

  const handleBlur = () => {
    setIsTouched(true);
    handleValidation(vin, true);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsTouched(true);
    if (handleValidation(vin, true)) {
      onSearch(vin);
    }
  };

  const handleExampleClick = (exampleVin: string) => {
    setVin(exampleVin);
    setValidationError(null);
    setIsTouched(true);
    onSearch(exampleVin);
  };

  const isButtonDisabled = isLoading || vin.trim().length !== 17 || !!validationError;

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl w-full">
      <div className="relative">
        <button 
          type="button" 
          onClick={onScannerClick}
          className="absolute left-2 top-1/2 -translate-y-1/2 p-2 text-gray-500 hover:text-blue-600"
          aria-label={t('vinInput.scanAriaLabel')}
        >
          <CameraIcon className="h-6 w-6" />
        </button>
        <input
          type="text"
          value={vin}
          onChange={handleChange}
          onBlur={handleBlur}
          placeholder={t('vinInput.placeholder')}
          className={`w-full pl-12 pr-40 py-4 text-lg border-2 rounded-full shadow-lg transition-shadow duration-300 ${validationError ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'}`}
          maxLength={17}
          disabled={isLoading}
          aria-invalid={!!validationError}
          aria-describedby="vin-error"
        />
        <button
          type="submit"
          className="absolute right-2 top-1/2 -translate-y-1/2 bg-blue-600 text-white font-bold py-3 px-8 rounded-full hover:bg-blue-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300"
          disabled={isButtonDisabled}
        >
          {isLoading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
          ) : (
            t('vinInput.button')
          )}
        </button>
      </div>
      {validationError && <p id="vin-error" className="text-center text-sm text-red-600 mt-2 font-semibold">{validationError}</p>}
      <div className="text-center text-sm text-gray-500 mt-4">
        <span className="mr-2 font-medium">{t('vinInput.example')}</span>
        <div className="inline-flex flex-wrap justify-center gap-2 mt-2 md:mt-0">
            {exampleVins.map(example => (
                 <button 
                    key={example.vin} 
                    type="button" 
                    onClick={() => handleExampleClick(example.vin)} 
                    className="font-mono text-xs text-blue-700 font-semibold bg-blue-100 hover:bg-blue-200 rounded-full px-3 py-1 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={isLoading}
                 >
                    {example.name}
                </button>
            ))}
        </div>
      </div>
    </form>
  );
};

export default VinInput;
