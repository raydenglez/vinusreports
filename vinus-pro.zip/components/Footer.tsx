import React from 'react';
import { useTranslation } from '../i18n/useTranslation';

interface FooterProps {
  onPolicyClick: () => void;
  onTermsClick: () => void;
}

const Footer: React.FC<FooterProps> = ({ onPolicyClick, onTermsClick }) => {
  const { t } = useTranslation();
  
  return (
    <footer className="bg-white border-t mt-auto print:hidden">
      <div className="w-full max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex justify-center space-x-6 md:order-2">
            {/* Social media icons can go here */}
          </div>
          <div className="mt-8 md:mt-0 md:order-1 text-center">
            <p className="text-base text-gray-500">{t('footer.copyright')}</p>
            <div className="mt-4 flex justify-center space-x-4 text-sm text-gray-500">
                <button onClick={onPolicyClick} className="hover:underline">{t('footer.privacyPolicy')}</button>
                <span>&middot;</span>
                <button onClick={onTermsClick} className="hover:underline">{t('footer.termsOfService')}</button>
            </div>
          </div>
        </div>
        <div className="mt-8 text-xs text-gray-400 text-center">
            <p>{t('footer.disclaimer')}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
