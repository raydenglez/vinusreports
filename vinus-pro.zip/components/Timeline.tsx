

import React from 'react';

interface TimelineProps<T> {
  title: string;
  items: T[];
  dateKey: keyof T;
  renderContent: (item: T) => React.ReactNode;
  emptyText?: string;
}

const Timeline = <T extends object>(props: TimelineProps<T>) => {
  const { title, items, dateKey, renderContent, emptyText = "No events to display." } = props;

  const sortedItems = [...items].sort((a, b) => 
    new Date(b[dateKey] as string).getTime() - new Date(a[dateKey] as string).getTime()
  );

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-bold mb-6">{title}</h3>
      {sortedItems.length > 0 ? (
        <div className="relative pl-6">
          <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>
          {sortedItems.map((item, index) => (
            <div key={index} className="relative mb-8 last:mb-0">
              <div className="absolute -left-2 top-1.5 h-4 w-4 bg-blue-600 rounded-full border-4 border-white"></div>
              <div className="ml-8">
                <p className="font-bold text-gray-800">
                  {new Date(item[dateKey] as string).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                </p>
                <div className="mt-2">{renderContent(item)}</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-500">{emptyText}</p>
      )}
    </div>
  );
};

export default Timeline;