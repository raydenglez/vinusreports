import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import { useTranslation } from '../i18n/useTranslation';
import { MailIcon } from './icons/Icons';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportVin: string;
}

const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, reportVin }) => {
  const { t } = useTranslation();
  const [copyStatus, setCopyStatus] = useState(t('shareModal.copy'));
  const shareUrl = `${window.location.origin}${window.location.pathname}#/report/${reportVin}`;

  const emailSubject = t('shareModal.emailSubject', { vin: reportVin });
  const emailBody = t('shareModal.emailBody', { url: shareUrl });
  const mailtoLink = `mailto:?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;

  useEffect(() => {
    // Reset button text when modal is closed
    if (!isOpen) {
      setTimeout(() => setCopyStatus(t('shareModal.copy')), 300);
    }
  }, [isOpen, t]);

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopyStatus(t('shareModal.copied'));
      setTimeout(() => setCopyStatus(t('shareModal.copy')), 2000);
    }, (err) => {
      console.error('Could not copy text: ', err);
    });
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={t('shareModal.title')}>
      <div className="space-y-4">
        <p className="text-sm text-gray-600">
          {t('shareModal.description')}
        </p>
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={shareUrl}
            readOnly
            className="flex-grow px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-700 text-sm focus:ring-blue-500 focus:border-blue-500"
            onFocus={(e) => e.target.select()}
            aria-label="Shareable report link"
          />
          <button
            onClick={handleCopy}
            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors w-24 flex-shrink-0 ${
              copyStatus === t('shareModal.copied')
                ? 'bg-green-600 text-white'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {copyStatus}
          </button>
          <a
            href={mailtoLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 p-2 text-sm font-semibold rounded-md bg-gray-500 text-white hover:bg-gray-600 transition-colors"
            aria-label={t('shareModal.email')}
            title={t('shareModal.email')}
          >
            <MailIcon className="h-5 w-5" />
          </a>
        </div>
      </div>
    </Modal>
  );
};

export default ShareModal;