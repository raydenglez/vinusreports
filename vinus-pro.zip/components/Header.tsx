import React from 'react';
import LanguageSelector from './LanguageSelector';
import { useTranslation } from '../i18n/useTranslation';

interface HeaderProps {
  isLoggedIn: boolean;
  onLogoClick: () => void;
  onFeaturesClick: () => void;
  onPricingClick: () => void;
  onPortalClick: () => void;
  onSignInClick: () => void;
  onLogoutClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  isLoggedIn,
  onLogoClick, 
  onFeaturesClick, 
  onPricingClick,
  onPortalClick,
  onSignInClick,
  onLogoutClick
}) => {
  const { t } = useTranslation();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50 print:hidden">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div 
            className="flex items-center cursor-pointer"
            onClick={onLogoClick}
          >
            <svg className="h-8 w-auto text-blue-600" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5L12 2z" fill="currentColor"/>
              <path d="M8.5 10l3.5 6 3.5-6" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="ml-2 text-2xl font-bold text-gray-800">VinUS Pro</span>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#features" onClick={(e) => { e.preventDefault(); onFeaturesClick(); }} className="text-gray-600 hover:text-blue-600">{t('header.features')}</a>
            <a href="#pricing" onClick={(e) => { e.preventDefault(); onPricingClick(); }} className="text-gray-600 hover:text-blue-600">{t('header.pricing')}</a>
            <button onClick={onPortalClick} className="text-gray-600 hover:text-blue-600">{t('header.portal')}</button>
          </nav>
          <div className="hidden md:flex items-center space-x-4">
            <LanguageSelector />
            {isLoggedIn ? (
               <button 
                onClick={onLogoutClick}
                className="items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
               >
                {t('header.signOut')}
              </button>
            ) : (
              <button 
                onClick={onSignInClick}
                className="items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {t('header.signIn')}
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
