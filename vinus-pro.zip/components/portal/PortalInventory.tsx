import React, { useState, useMemo } from 'react';
import type { VehicleReport } from '../../types';
import VinInput from '../VinInput';
import Modal from '../Modal';
import VinScanner from '../VinScanner';
import { useTranslation } from '../../i18n/useTranslation';

interface PortalInventoryProps {
    onRunReport: (vin: string) => void;
    inventory: VehicleReport[];
    onViewReport: (report: VehicleReport) => void;
}

const RiskFlagBadge: React.FC<{ flag: string }> = ({ flag }) => {
    const isMajor = /salvage|rebuilt|rollback|stolen/i.test(flag);
    const colorClasses = isMajor ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800';
    return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${colorClasses}`}>{flag}</span>;
}

const PortalInventory: React.FC<PortalInventoryProps> = ({ onRunReport, inventory, onViewReport }) => {
    const { t } = useTranslation();
    const [searchTerm, setSearchTerm] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isScannerOpen, setIsScannerOpen] = useState(false);

    const handleSearch = (vin: string) => {
        setIsLoading(true);
        onRunReport(vin);
    };

    const handleScannerSearch = (vin: string) => {
        setIsScannerOpen(false);
        handleSearch(vin);
    };

    const filteredInventory = useMemo(() => {
        if (!searchTerm) {
            return inventory;
        }
        return inventory.filter(report =>
            report.vin.toLowerCase().includes(searchTerm.toLowerCase()) ||
            report.make.toLowerCase().includes(searchTerm.toLowerCase()) ||
            report.model.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [searchTerm, inventory]);

    return (
        <div className="space-y-6 animate-fade-in">
            <Modal 
                isOpen={isScannerOpen} 
                onClose={() => setIsScannerOpen(false)}
                title={t('vinScanner.modalTitle')}
            >
                <VinScanner onSearch={handleScannerSearch} onClose={() => setIsScannerOpen(false)} />
            </Modal>
            <div>
                <h1 className="text-3xl font-bold text-gray-900">{t('portal.inventory.title')}</h1>
                <p className="text-gray-600 mt-1">{t('portal.inventory.subtitle')}</p>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg border">
                <h3 className="font-bold text-lg mb-4">{t('portal.inventory.newReportTitle')}</h3>
                <VinInput onSearch={handleSearch} isLoading={isLoading} exampleVins={[]} onScannerClick={() => setIsScannerOpen(true)} />
            </div>

            <div className="bg-white border rounded-lg">
                 <div className="p-4 border-b">
                    <input
                        type="text"
                        placeholder={t('portal.inventory.searchPlaceholder')}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                </div>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('tableHeaders.vehicle')}</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('tableHeaders.vin')}</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('tableHeaders.score')}</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('tableHeaders.riskFlags')}</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {filteredInventory.map(report => (
                                <tr 
                                    key={report.id} 
                                    className="hover:bg-gray-50 cursor-pointer"
                                    onClick={() => onViewReport(report)}
                                >
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="text-sm font-medium text-gray-900">{`${report.year} ${report.make} ${report.model}`}</div>
                                        <div className="text-sm text-gray-500">{report.trim}</div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="text-sm text-gray-900 font-mono">{report.vin}</div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${report.scorecard.transparency_score >= 80 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                            {report.scorecard.transparency_score}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <div className="flex flex-wrap gap-1">
                                            {report.scorecard.risk_flags.length > 0 ? report.scorecard.risk_flags.map(flag => (
                                                <RiskFlagBadge key={flag} flag={flag} />
                                            )) : <span className="text-green-700">{t('portal.inventory.riskFlagNone')}</span>}
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 {filteredInventory.length === 0 && <p className="text-center p-6 text-gray-500">{t('portal.inventory.noResults')}</p>}
            </div>
        </div>
    );
};

export default PortalInventory;
