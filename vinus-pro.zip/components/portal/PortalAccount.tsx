import React, { useState } from 'react';
import type { UserSubscription, BillingCycle } from '../../types';
import { useTranslation } from '../../i18n/useTranslation';

interface PortalAccountProps {
    subscription: UserSubscription | null;
    setSubscription: React.Dispatch<React.SetStateAction<UserSubscription | null>>;
}

const PortalAccount: React.FC<PortalAccountProps> = ({ subscription, setSubscription }) => {
    const { t } = useTranslation();
    const [isChangingPlan, setIsChangingPlan] = useState(false);

    if (!subscription) {
        return (
            <div>
                <h1 className="text-3xl font-bold text-gray-900">{t('portal.account.title')}</h1>
                <p className="mt-4 text-gray-600">{t('portal.account.noSubscription')}</p>
            </div>
        )
    }

    const handleCancel = () => {
        setSubscription(prev => prev ? { ...prev, status: 'canceled' } : null);
    };

    const handleReactivate = () => {
        setSubscription(prev => prev ? { ...prev, status: 'active' } : null);
    };

    const handleChangePlan = (newCycle: BillingCycle) => {
        if (newCycle === subscription.billingCycle) {
            setIsChangingPlan(false);
            return;
        }
        
        const newPrice = newCycle === 'monthly' ? 39 : 390;

        setSubscription(prev => prev ? { 
            ...prev,
            billingCycle: newCycle,
            price: newPrice,
        } : null);
        setIsChangingPlan(false);
    };
    
    const isCanceled = subscription.status === 'canceled';

    const renderPlanChangeModal = () => (
        <div className="mt-4 border-t pt-4">
            <h3 className="font-bold text-lg">{t('portal.account.changeBillingCycle')}</h3>
            <div className="mt-4 space-y-4">
                <button
                    onClick={() => handleChangePlan('monthly')}
                    className={`w-full text-left p-4 border rounded-lg ${subscription.billingCycle === 'monthly' ? 'border-blue-600 bg-blue-50' : ''}`}
                >
                    <p className="font-semibold">{t('portal.account.monthlyPlan')}</p>
                    <p className="text-sm text-gray-600">{t('portal.account.monthlyDesc')}</p>
                </button>
                <button
                    onClick={() => handleChangePlan('yearly')}
                    className={`w-full text-left p-4 border rounded-lg ${subscription.billingCycle === 'yearly' ? 'border-blue-600 bg-blue-50' : ''}`}
                >
                    <p className="font-semibold">{t('portal.account.yearlyPlan')} <span className="text-green-600">({t('pricingTiers.save')})</span></p>
                    {subscription.billingCycle === 'monthly' ? (
                         <p className="text-sm text-gray-600">{t('portal.account.yearlyDescUpgrade')}</p>
                    ): (
                        <p className="text-sm text-gray-600">{t('portal.account.yearlyDescCurrent')}</p>
                    )}
                </button>
            </div>
             <button onClick={() => setIsChangingPlan(false)} className="mt-4 text-sm text-blue-600 hover:underline">{t('portal.account.cancel')}</button>
        </div>
    );

    return (
        <div className="space-y-8 animate-fade-in max-w-3xl">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">{t('portal.account.title')}</h1>
                <p className="text-gray-600 mt-1">{t('portal.account.subtitle')}</p>
            </div>
            
            {isCanceled && (
                 <div className="p-4 rounded-md bg-yellow-50 text-yellow-800 border border-yellow-200">
                    <p className="font-semibold">{t('portal.account.canceledMessage')}</p>
                    <p className="text-sm">{t('portal.account.benefitsEnd', { date: subscription.nextBillingDate })}</p>
                </div>
            )}

            <div className="bg-white border rounded-lg p-6">
                <h2 className="text-xl font-bold text-gray-800">{t('portal.account.currentPlan')}</h2>
                <div className="mt-4 md:flex justify-between items-start">
                    <div>
                        <p className="text-3xl font-extrabold text-blue-600">{subscription.planName}</p>
                        <p className="text-gray-500 capitalize">${subscription.price} / {subscription.billingCycle === 'monthly' ? t('pricingTiers.priceSuffixMonth').substring(2) : t('pricingTiers.priceSuffixYear').substring(2)}</p>
                    </div>
                    <div className="flex flex-col md:items-end mt-4 md:mt-0 space-y-2">
                         {isCanceled ? (
                             <button onClick={handleReactivate} className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md shadow-sm hover:bg-blue-700">
                                {t('portal.account.reactivate')}
                            </button>
                         ) : (
                            <>
                                <button onClick={() => setIsChangingPlan(!isChangingPlan)} className="px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50">
                                    {isChangingPlan ? t('portal.account.closePlanOptions') : t('portal.account.changePlan')}
                                </button>
                                <button onClick={handleCancel} className="text-sm text-red-600 hover:underline">
                                    {t('portal.account.cancelSubscription')}
                                </button>
                            </>
                         )}
                    </div>
                </div>
                {isChangingPlan && !isCanceled && renderPlanChangeModal()}
            </div>

            <div className="bg-white border rounded-lg p-6">
                <h2 className="text-xl font-bold text-gray-800">{t('portal.account.currentPeriod')}</h2>
                <p className="text-sm text-gray-500 mb-4">
                    {isCanceled ? t('portal.account.benefitsEnd', { date: subscription.nextBillingDate }) : t('portal.account.renewsOn', { date: subscription.nextBillingDate })}
                </p>
                
                <div>
                    <div className="flex justify-between mb-1">
                        <span className="text-base font-medium text-blue-700">{t('portal.account.reportUsage')}</span>
                        <span className="text-sm font-medium text-blue-700">{t('portal.account.usageOf', { used: subscription.reportsUsed, total: subscription.reportsIncluded })}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${(subscription.reportsUsed / subscription.reportsIncluded) * 100}%` }}></div>
                    </div>
                </div>
            </div>

             <div className="bg-white border rounded-lg">
                 <div className="p-6">
                    <h2 className="text-xl font-bold text-gray-800">{t('portal.account.billingHistory')}</h2>
                 </div>
                 <ul className="divide-y">
                     <li className="p-4 flex justify-between items-center text-sm">
                         <span>September 2024</span>
                         <span>$39.00</span>
                         <a href="#" className="text-blue-600 hover:underline">{t('portal.account.download')}</a>
                     </li>
                      <li className="p-4 flex justify-between items-center text-sm">
                         <span>August 2024</span>
                         <span>$39.00</span>
                         <a href="#" className="text-blue-600 hover:underline">{t('portal.account.download')}</a>
                     </li>
                      <li className="p-4 flex justify-between items-center text-sm">
                         <span>July 2024</span>
                         <span>$39.00</span>
                         <a href="#" className="text-blue-600 hover:underline">{t('portal.account.download')}</a>
                     </li>
                 </ul>
             </div>
        </div>
    );
};

export default PortalAccount;
