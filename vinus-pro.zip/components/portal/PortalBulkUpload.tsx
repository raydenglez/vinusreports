import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { UploadIcon, CheckCircleIcon, ShieldExclamationIcon } from '../icons/Icons';
import { useTranslation } from '../../i18n/useTranslation';

const PortalBulkUpload: React.FC = () => {
    const { t } = useTranslation();
    const [files, setFiles] = useState<File[]>([]);
    const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
    const [message, setMessage] = useState('');

    const onDrop = useCallback((acceptedFiles: File[]) => {
        setFiles(acceptedFiles);
        setStatus('idle');
        setMessage('');
    }, []);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: { 'text/csv': ['.csv'] },
        maxFiles: 1,
    });
    
    const handleProcess = () => {
        if (files.length === 0) {
            setStatus('error');
            setMessage(t('portal.bulkUpload.status.selectFile'));
            return;
        }
        setStatus('processing');
        setMessage(t('portal.bulkUpload.status.validating'));

        const reader = new FileReader();
        
        reader.onload = (event) => {
            try {
                const text = event.target?.result as string;
                if (!text) {
                    throw new Error("File is empty.");
                }
                const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
                
                const vinCount = lines.length > 1 ? lines.length - 1 : 0;
                
                if (lines.length === 0 || (vinCount === 0 && lines.length === 1)) {
                     setStatus('error');
                     setMessage(t('portal.bulkUpload.status.emptyFile'));
                     setFiles([]);
                     return;
                }

                if (vinCount > 20) {
                    setStatus('error');
                    setMessage(t('portal.bulkUpload.status.limitExceeded', { count: vinCount }));
                    setFiles([]);
                    return;
                }

                setMessage(t('portal.bulkUpload.status.processing', { count: vinCount }));
                setTimeout(() => {
                    setStatus('success');
                    setMessage(t('portal.bulkUpload.status.success', { count: vinCount, fileName: files[0].name }));
                    setFiles([]);
                }, 2000);

            } catch (e) {
                setStatus('error');
                setMessage(t('portal.bulkUpload.status.parseError'));
                console.error(e);
            }
        };

        reader.onerror = () => {
            setStatus('error');
            setMessage(t('portal.bulkUpload.status.readError'));
        };

        reader.readAsText(files[0]);
    };

    return (
        <div className="space-y-6 animate-fade-in max-w-3xl mx-auto">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">{t('portal.bulkUpload.title')}</h1>
                <p className="text-gray-600 mt-1">{t('portal.bulkUpload.subtitle')}</p>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg border">
                <h3 className="font-bold text-lg">{t('portal.bulkUpload.instructionsTitle')}</h3>
                <ul className="list-disc list-inside mt-2 text-gray-600 text-sm space-y-1">
                    <li>{t('portal.bulkUpload.instruction1')}</li>
                    <li>{t('portal.bulkUpload.instruction2')}</li>
                    <li>{t('portal.bulkUpload.instruction3')}</li>
                    <li>{t('portal.bulkUpload.instruction4')}</li>
                </ul>
            </div>
            
            <div className="text-center">
                <div 
                    {...getRootProps()} 
                    className={`p-12 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-white hover:border-gray-400'}`}
                >
                    <input {...getInputProps()} />
                    <UploadIcon className="h-12 w-12 text-gray-400 mx-auto" />
                    {files.length > 0 ? (
                         <p className="mt-4 text-gray-700">{t('portal.bulkUpload.selectedFile', { fileName: files[0].name })}</p>
                    ) : (
                         <p className="mt-4 text-gray-600">{isDragActive ? t('portal.bulkUpload.dropzoneActive') : t('portal.bulkUpload.dropzoneIdle')}</p>
                    )}
                </div>
            </div>
            
            <button
              onClick={handleProcess}
              disabled={status === 'processing' || files.length === 0}
              className="w-full bg-blue-600 text-white font-bold py-3 px-8 rounded-lg hover:bg-blue-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300 disabled:cursor-not-allowed"
            >
              {status === 'processing' ? t('portal.bulkUpload.processingButton') : t('portal.bulkUpload.processButton')}
            </button>
            
            {message && (
                <div className={`p-4 rounded-md flex items-center ${
                    status === 'success' ? 'bg-green-50 text-green-800' :
                    status === 'error' ? 'bg-red-50 text-red-800' :
                    'bg-blue-50 text-blue-800'
                }`}>
                    {status === 'success' && <CheckCircleIcon className="h-5 w-5 mr-3" />}
                    {status === 'error' && <ShieldExclamationIcon className="h-5 w-5 mr-3" />}
                    <p className="text-sm font-medium">{message}</p>
                </div>
            )}
        </div>
    );
};

export default PortalBulkUpload;
