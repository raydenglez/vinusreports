import React from 'react';
import type { VehicleReport, UserSubscription } from '../../types';
import { DocumentReportIcon, CheckCircleIcon, ShieldExclamationIcon } from '../icons/Icons';
import { useTranslation } from '../../i18n/useTranslation';

interface PortalDashboardProps {
    setActiveSection: (section: 'dashboard' | 'inventory' | 'upload' | 'account') => void;
    recentReports: VehicleReport[];
    onViewReport: (report: VehicleReport) => void;
    subscription: UserSubscription | null;
}

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <div className="bg-gray-100 p-6 rounded-lg flex items-center">
        <div className="bg-blue-200 text-blue-700 p-3 rounded-full mr-4">
            {icon}
        </div>
        <div>
            <p className="text-sm text-gray-600">{title}</p>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
        </div>
    </div>
);


const PortalDashboard: React.FC<PortalDashboardProps> = ({ setActiveSection, recentReports, onViewReport, subscription }) => {
    const { t } = useTranslation();

    return (
        <div className="space-y-8 animate-fade-in">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">{t('portal.dashboard.welcome')}</h1>
                <p className="text-gray-600 mt-1">{t('portal.dashboard.snapshot')}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard title={t('portal.dashboard.reportsThisMonth')} value={(subscription?.reportsUsed || 0).toString()} icon={<DocumentReportIcon className="h-6 w-6" />} />
                <StatCard title={t('portal.dashboard.planUsage')} value={`${subscription?.reportsUsed || 0} / ${subscription?.reportsIncluded || 0}`} icon={<CheckCircleIcon className="h-6 w-6" />} />
                <StatCard title={t('portal.dashboard.activeRiskFlags')} value="3" icon={<ShieldExclamationIcon className="h-6 w-6" />} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                 <button onClick={() => setActiveSection('inventory')} className="text-left w-full bg-blue-600 text-white p-6 rounded-lg hover:bg-blue-700 transition-all transform hover:scale-105">
                    <h3 className="text-xl font-bold">{t('portal.dashboard.runSingleVin')}</h3>
                    <p className="mt-1">{t('portal.dashboard.runSingleVinDesc')}</p>
                </button>
                <button onClick={() => setActiveSection('upload')} className="text-left w-full bg-gray-700 text-white p-6 rounded-lg hover:bg-gray-800 transition-all transform hover:scale-105">
                    <h3 className="text-xl font-bold">{t('portal.dashboard.bulkUpload')}</h3>
                    <p className="mt-1">{t('portal.dashboard.bulkUploadDesc')}</p>
                </button>
            </div>

            <div>
                <h2 className="text-2xl font-bold text-gray-800 mb-4">{t('portal.dashboard.recentReports')}</h2>
                <div className="bg-white border rounded-lg overflow-hidden">
                    <ul className="divide-y">
                        {recentReports.map(report => (
                            <li 
                                key={report.id} 
                                className="p-4 flex justify-between items-center hover:bg-gray-50 cursor-pointer"
                                onClick={() => onViewReport(report)}
                            >
                                <div>
                                    <p className="font-semibold">{`${report.year} ${report.make} ${report.model}`}</p>
                                    <p className="text-sm font-mono text-gray-500">{report.vin}</p>
                                </div>
                                <div className="text-right">
                                     <span className={`px-2 py-1 text-xs font-semibold rounded-full ${report.scorecard.transparency_score >= 80 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                       {t('tableHeaders.score')}: {report.scorecard.transparency_score}
                                     </span>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default PortalDashboard;
