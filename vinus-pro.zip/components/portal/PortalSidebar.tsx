import React from 'react';
import { DashboardIcon, InventoryIcon, UploadIcon, UserIcon, LogoutIcon } from '../icons/Icons';
import { useTranslation } from '../../i18n/useTranslation';

type PortalSection = 'dashboard' | 'inventory' | 'upload' | 'account';

interface PortalSidebarProps {
    activeSection: PortalSection;
    setActiveSection: (section: PortalSection) => void;
    onLogout: () => void;
}

const PortalSidebar: React.FC<PortalSidebarProps> = ({ activeSection, setActiveSection, onLogout }) => {
    const { t } = useTranslation();
    
    const navItems = [
        { id: 'dashboard', label: t('portal.sidebar.dashboard'), icon: <DashboardIcon className="h-5 w-5" /> },
        { id: 'inventory', label: t('portal.sidebar.inventory'), icon: <InventoryIcon className="h-5 w-5" /> },
        { id: 'upload', label: t('portal.sidebar.bulkUpload'), icon: <UploadIcon className="h-5 w-5" /> },
        { id: 'account', label: t('portal.sidebar.account'), icon: <UserIcon className="h-5 w-5" /> },
    ];

    return (
        <aside className="w-full md:w-64 bg-gray-50 p-4 md:p-6 rounded-l-xl border-b md:border-b-0 md:border-r">
            <div className="flex flex-row md:flex-col justify-between h-full">
                <nav className="flex flex-row md:flex-col md:space-y-2 -mx-2 md:mx-0">
                    {navItems.map(item => (
                        <button
                            key={item.id}
                            onClick={() => setActiveSection(item.id as PortalSection)}
                            className={`flex items-center px-3 py-3 text-sm font-medium rounded-lg transition-colors duration-200 ${activeSection === item.id
                                ? 'bg-blue-100 text-blue-700'
                                : 'text-gray-600 hover:bg-gray-200'
                                }`}
                        >
                            {item.icon}
                            <span className="ml-3 hidden md:block">{item.label}</span>
                        </button>
                    ))}
                </nav>
                 <button
                    onClick={onLogout}
                    className="flex items-center px-3 py-3 text-sm font-medium rounded-lg text-gray-600 hover:bg-gray-200 transition-colors duration-200"
                >
                    <LogoutIcon className="h-5 w-5" />
                    <span className="ml-3 hidden md:block">{t('portal.sidebar.signOut')}</span>
                </button>
            </div>
        </aside>
    );
};

export default PortalSidebar;
