
import React, { useState } from 'react';
import PortalSidebar from './PortalSidebar';
import PortalDashboard from './PortalDashboard';
import PortalInventory from './PortalInventory';
import PortalBulkUpload from './PortalBulkUpload';
import PortalAccount from './PortalAccount';
import type { VehicleReport, UserSubscription } from '../../types';

type PortalSection = 'dashboard' | 'inventory' | 'upload' | 'account';

interface DealerPortalProps {
    onLogout: () => void;
    onRunReport: (vin: string) => void;
    savedReports: VehicleReport[];
    onViewReport: (report: VehicleReport) => void;
    subscription: UserSubscription | null;
    setSubscription: React.Dispatch<React.SetStateAction<UserSubscription | null>>;
}

const DealerPortal: React.FC<DealerPortalProps> = ({ onLogout, onRunReport, savedReports, onViewReport, subscription, setSubscription }) => {
    const [activeSection, setActiveSection] = useState<PortalSection>('dashboard');

    const renderSection = () => {
        switch (activeSection) {
            case 'dashboard':
                return <PortalDashboard 
                            setActiveSection={setActiveSection} 
                            recentReports={savedReports.slice(0, 3)}
                            onViewReport={onViewReport}
                            subscription={subscription}
                       />;
            case 'inventory':
                return <PortalInventory 
                            onRunReport={onRunReport} 
                            inventory={savedReports} 
                            onViewReport={onViewReport} 
                       />;
            case 'upload':
                return <PortalBulkUpload />;
            case 'account':
                return <PortalAccount 
                            subscription={subscription}
                            setSubscription={setSubscription}
                       />;
            default:
                return <PortalDashboard 
                            setActiveSection={setActiveSection} 
                            recentReports={savedReports.slice(0, 3)} 
                            onViewReport={onViewReport}
                            subscription={subscription}
                       />;
        }
    }

    return (
        <div className="flex flex-col md:flex-row bg-white rounded-xl shadow-lg min-h-[70vh]">
            <PortalSidebar
                activeSection={activeSection}
                setActiveSection={setActiveSection}
                onLogout={onLogout}
            />
            <div className="flex-1 p-6 md:p-8 overflow-y-auto">
                {renderSection()}
            </div>
        </div>
    );
};

export default DealerPortal;
