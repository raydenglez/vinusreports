import React from 'react';
import type { OwnershipCost as OwnershipCostType } from '../types';
import { currencyFormatter } from '../utils/formatters';
import { WrenchIcon, FuelIcon, InsuranceIcon } from './icons/Icons';
import { useTranslation } from '../i18n/useTranslation';

interface OwnershipCostProps {
  cost: OwnershipCostType;
}

const CostItem: React.FC<{ icon: React.ReactNode; label: string; value: number }> = ({ icon, label, value }) => (
    <div className="flex items-center space-x-3">
        <div className="flex-shrink-0 bg-blue-100 text-blue-600 p-2 rounded-full">
            {icon}
        </div>
        <div>
            <p className="text-sm text-gray-500">{label}</p>
            <p className="font-bold text-lg text-gray-800">{currencyFormatter.format(value)}</p>
        </div>
    </div>
);

const OwnershipCost: React.FC<OwnershipCostProps> = ({ cost }) => {
  const { t } = useTranslation();

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-bold">{t('reportSections.ownershipCost')}</h3>
      <div className="my-4 text-center">
        <p className="text-4xl font-extrabold text-gray-900">{currencyFormatter.format(cost.five_year_total)}</p>
        <p className="text-sm text-gray-500">{t('ownershipCost.total')}</p>
      </div>
      <div className="space-y-4 pt-4 border-t">
        <CostItem icon={<WrenchIcon className="h-5 w-5"/>} label={t('ownershipCost.maintenance')} value={cost.maintenance}/>
        <CostItem icon={<FuelIcon className="h-5 w-5"/>} label={t('ownershipCost.fuel')} value={cost.fuel}/>
        <CostItem icon={<InsuranceIcon className="h-5 w-5"/>} label={t('ownershipCost.insurance')} value={cost.insurance}/>
      </div>
    </div>
  );
};

export default OwnershipCost;
