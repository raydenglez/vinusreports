import React from 'react';
import type { VehicleReport } from '../types';
import { CheckCircleIcon, ShieldExclamationIcon, CalendarIcon, DatabaseIcon, CarIcon, ShieldCheckIcon, TagIcon } from './icons/Icons';
import { useTranslation } from '../i18n/useTranslation';

interface ReportSummaryProps {
  report: VehicleReport;
  isFreePreview?: boolean;
}

const ScoreBadge: React.FC<{ score: number }> = ({ score }) => {
  const { t } = useTranslation();
  const getColor = () => {
    if (score >= 90) return 'bg-green-500';
    if (score >= 70) return 'bg-yellow-500';
    return 'bg-red-500';
  };
  return (
    <div className="text-center">
      <div className={`mx-auto h-24 w-24 rounded-full flex items-center justify-center text-white text-4xl font-bold ${getColor()}`}>
        {score}
      </div>
      <p className="mt-2 font-semibold text-gray-700">{t('reportSummary.score')}</p>
    </div>
  );
};

const HighlightItem: React.FC<{ icon: React.ReactNode; text: string; isRisk?: boolean }> = ({ icon, text, isRisk = false }) => (
  <div className={`flex items-center p-3 rounded-lg ${isRisk ? 'bg-red-50' : 'bg-green-50'}`}>
    <div className={`flex-shrink-0 ${isRisk ? 'text-red-500' : 'text-green-500'}`}>{icon}</div>
    <p className={`ml-3 font-medium ${isRisk ? 'text-red-800' : 'text-green-800'}`}>{text}</p>
  </div>
);

const GlanceBadge: React.FC<{ icon: React.ReactNode; label: string; value: string; isLocked?: boolean }> = ({ icon, label, value, isLocked }) => (
    <div className={`flex items-center p-3 rounded-lg ${isLocked ? 'bg-gray-200' : 'bg-gray-100'}`}>
        <div className="flex-shrink-0 text-blue-600">{icon}</div>
        <div className="ml-3">
            <p className="text-sm text-gray-500">{label}</p>
            <p className="font-bold text-gray-800">{value}</p>
        </div>
    </div>
);


const ReportSummary: React.FC<ReportSummaryProps> = ({ report, isFreePreview = false }) => {
  const { t } = useTranslation();
  const { year, make, model, trim, vin, scorecard, decoded_at, ownershipHistory, accidents, titlesAndBrands } = report;

  const ownerCount = ownershipHistory.length;
  const hasAccidents = accidents.length > 0;
  const hasSalvage = titlesAndBrands.some(t => t.brand.toLowerCase().includes('salvage') || t.brand.toLowerCase().includes('rebuilt'));

  const ownerValue = isFreePreview 
    ? t('reportSummary.locked') 
    : `${ownerCount} ${ownerCount === 1 ? t('reportSummary.owner') : t('reportSummary.owners')}`;

  const accidentValue = isFreePreview 
    ? t('reportSummary.locked') 
    : (hasAccidents ? `${accidents.length} ${t('reportSummary.reported')}` : t('reportSummary.noneReported'));

  const titleValue = isFreePreview 
    ? t('reportSummary.locked') 
    : (hasSalvage ? t('reportSummary.salvage') : t('reportSummary.clean'));

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="grid grid-cols-1 md:grid-cols-12">
        <div className="md:col-span-8 p-6">
          <h2 className="text-2xl font-bold text-gray-900">{`${year} ${make} ${model}`}</h2>
          <p className="text-lg text-gray-600">{trim}</p>
          <p className="mt-1 text-sm font-mono text-gray-500">{vin}</p>
          
          <div className="mt-4 grid grid-cols-2 lg:grid-cols-3 gap-4">
              <GlanceBadge icon={<CarIcon className="h-6 w-6"/>} label={t('reportSummary.owners')} value={ownerValue} isLocked={isFreePreview} />
              <GlanceBadge icon={<ShieldExclamationIcon className="h-6 w-6"/>} label={t('reportSummary.accidents')} value={accidentValue} isLocked={isFreePreview} />
              <GlanceBadge icon={<TagIcon className="h-6 w-6"/>} label={t('reportSummary.titleStatus')} value={titleValue} isLocked={isFreePreview} />
          </div>

          {!isFreePreview && (
            <div className="mt-6 pt-4 border-t border-gray-200 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-3">
                  {scorecard.highlights.map(highlight => (
                      <HighlightItem key={highlight} icon={<CheckCircleIcon className="h-6 w-6"/>} text={highlight} />
                  ))}
                </div>
                <div className="space-y-3">
                  {scorecard.risk_flags.map(risk => (
                      <HighlightItem key={risk} icon={<ShieldCheckIcon className="h-6 w-6"/>} text={risk} isRisk={true} />
                  ))}
                </div>
            </div>
          )}
        </div>
        <div className="md:col-span-4 bg-gray-50 p-6 flex flex-col items-center justify-center border-l">
            <ScoreBadge score={scorecard.transparency_score} />
            <div className="mt-4 pt-4 border-t w-full space-y-2 text-center">
                 <div className="flex items-center justify-center text-xs text-gray-600">
                    <CalendarIcon className="h-4 w-4 mr-2 text-gray-400 flex-shrink-0" />
                    <span>{t('reportSummary.generated')}: {new Date(decoded_at).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center justify-center text-xs text-gray-600">
                    <DatabaseIcon className="h-4 w-4 mr-2 text-gray-400 flex-shrink-0" />
                    <span>{t('reportSummary.verified')}</span>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ReportSummary;
