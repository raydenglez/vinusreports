import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { validateVin } from '../utils/vinValidator';
import { CameraIcon, UploadIcon, CheckCircleIcon, ShieldExclamationIcon } from './icons/Icons';
import { HONDA_ACCORD_VIN, JEEP_WRANGLER_VIN } from '../constants';
import { useTranslation } from '../i18n/useTranslation';

interface VinScannerProps {
  onSearch: (vin: string) => void;
  onClose: () => void;
}

const VinScanner: React.FC<VinScannerProps> = ({ onSearch, onClose }) => {
  const { t } = useTranslation();
  const [mode, setMode] = useState<'live' | 'upload'>('live');
  const [isScanning, setIsScanning] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'info' | 'error' | 'success', message: string, suggestion?: string } | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  const startCamera = useCallback(async () => {
    stopCamera();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      setFeedback({ type: 'error', message: t('vinScanner.feedback.errorCamera') });
    }
  }, [stopCamera, t]);
  
  useEffect(() => {
    if (mode === 'live') {
      startCamera();
    } else {
      stopCamera();
    }
    
    return () => stopCamera();
  }, [mode, startCamera, stopCamera]);


  const handleScan = () => {
    setIsScanning(true);
    setFeedback({ type: 'info', message: t('vinScanner.feedback.infoScanning') });
    
    setTimeout(() => {
        const mockVin = Math.random() > 0.5 ? HONDA_ACCORD_VIN : JEEP_WRANGLER_VIN;
        handleVinFound(mockVin);
    }, 2500);
  };
  
  const handleVinFound = (vin: string) => {
      const result = validateVin(vin);
      if (result.isValid) {
          setFeedback({ 
              type: 'success', 
              message: t('vinScanner.feedback.success', { vin }),
              suggestion: result.suggestion ? t('vinValidator.suggestion', { suggestion: result.suggestion }) : undefined
          });
          setTimeout(() => {
              onSearch(vin);
              onClose();
          }, 1500);
      } else {
          setFeedback({ type: 'error', message: t(result.messageKey) });
      }
      setIsScanning(false);
  }

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
        setIsScanning(true);
        setFeedback({ type: 'info', message: t('vinScanner.feedback.infoProcessing', { fileName: acceptedFiles[0].name }) });
        setTimeout(() => {
            const mockVin = Math.random() > 0.5 ? HONDA_ACCORD_VIN : JEEP_WRANGLER_VIN;
            handleVinFound(mockVin);
        }, 2000);
    }
  }, [t]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': ['.jpeg', '.png'] },
    maxFiles: 1,
  });

  return (
    <div className="space-y-4">
      <div className="flex justify-center bg-gray-100 p-1 rounded-full">
        <button onClick={() => setMode('live')} className={`px-4 py-2 w-1/2 rounded-full font-semibold ${mode === 'live' ? 'bg-blue-600 text-white' : 'text-gray-600'}`}>{t('vinScanner.liveScan')}</button>
        <button onClick={() => setMode('upload')} className={`px-4 py-2 w-1/2 rounded-full font-semibold ${mode === 'upload' ? 'bg-blue-600 text-white' : 'text-gray-600'}`}>{t('vinScanner.uploadPhoto')}</button>
      </div>

      <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden">
        {mode === 'live' ? (
          <>
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover"></video>
            <div className="absolute inset-0 flex items-center justify-center p-4">
              <div className="w-full h-1/3 border-4 border-white border-dashed rounded-lg opacity-75"></div>
            </div>
          </>
        ) : (
          <div {...getRootProps()} className={`w-full h-full flex flex-col items-center justify-center border-2 border-dashed rounded-lg cursor-pointer transition-colors ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-gray-100 hover:border-gray-400'}`}>
            <input {...getInputProps()} />
            <UploadIcon className="h-12 w-12 text-gray-400" />
            <p className="mt-2 text-gray-600">{t('vinScanner.dropzone')}</p>
          </div>
        )}
      </div>

      {feedback && (
        <div className={`p-3 rounded-md flex items-start text-sm ${
            feedback.type === 'success' ? 'bg-green-50 text-green-800' :
            feedback.type === 'error' ? 'bg-red-50 text-red-800' :
            'bg-blue-50 text-blue-800'
        }`}>
            {feedback.type === 'success' && <CheckCircleIcon className="h-5 w-5 mr-2 flex-shrink-0" />}
            {feedback.type === 'error' && <ShieldExclamationIcon className="h-5 w-5 mr-2 flex-shrink-0" />}
            <div>
              <p>{feedback.message}</p>
              {feedback.suggestion && <p className="font-semibold mt-1">{feedback.suggestion}</p>}
            </div>
        </div>
      )}

      {mode === 'live' && (
        <button 
          onClick={handleScan} 
          disabled={isScanning}
          className="w-full bg-blue-600 text-white font-bold py-3 px-8 rounded-lg hover:bg-blue-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300 flex items-center justify-center"
        >
          {isScanning ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
          ) : (
            <>
              <CameraIcon className="h-6 w-6 mr-2" />
              {t('vinScanner.scanButton')}
            </>
          )}
        </button>
      )}
    </div>
  );
};

export default VinScanner;
