import React from 'react';
import type { OdometerEvent } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Dot } from 'recharts';
import { numberFormatter } from '../utils/formatters';
import { useTranslation } from '../i18n/useTranslation';

interface OdometerChartProps {
  data: OdometerEvent[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  const { t } = useTranslation();
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 border rounded shadow-lg">
        <p className="font-bold">{new Date(label).toLocaleDateString()}</p>
        <p className="text-blue-600">{`${t('odometerChart.tooltipReading')}: ${numberFormatter.format(payload[0].value)} ${t('odometerChart.tooltipMiles')}`}</p>
        <p className="text-gray-600 text-sm">{t('odometerChart.tooltipSource')}: {payload[0].payload.source}</p>
      </div>
    );
  }
  return null;
};

const CustomizedDot = (props: any) => {
    const { cx, cy, payload } = props;

    if (payload.flagged_rollback) {
        return (
            <svg x={cx - 10} y={cy - 10} width="20" height="20" fill="red" viewBox="0 0 1024 1024">
                <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm-32 232c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v272c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V296zm32 440a48 48 0 100-96 48 48 0 000 96z" />
            </svg>
        );
    }

    return <Dot cx={cx} cy={cy} r={4} fill="#3b82f6" />;
};

const OdometerChart: React.FC<OdometerChartProps> = ({ data }) => {
  const { t } = useTranslation();
  const sortedData = [...data].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-bold mb-4">{t('odometerChart.title')}</h3>
      <div className="w-full h-[300px] print:h-auto">
        <ResponsiveContainer>
          <LineChart
            data={sortedData}
            margin={{ top: 5, right: 20, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date" 
              tickFormatter={(tick) => new Date(tick).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })} 
              minTickGap={20}
            />
            <YAxis 
              tickFormatter={(tick) => numberFormatter.format(tick)}
              domain={['dataMin - 5000', 'dataMax + 5000']}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="reading" 
              stroke="#3b82f6" 
              strokeWidth={2}
              dot={<CustomizedDot/>}
              activeDot={{ r: 8 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      {data.some(d => d.flagged_rollback) && (
          <div className="mt-4 flex items-center bg-red-50 p-3 rounded-md">
            <svg className="h-6 w-6 text-red-500 mr-3" fill="currentColor" viewBox="0 0 1024 1024"><path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm-32 232c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v272c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V296zm32 440a48 48 0 100-96 48 48 0 000 96z" /></svg>
            <p className="text-red-700 font-semibold">{t('odometerChart.rollbackWarning')}</p>
          </div>
      )}
    </div>
  );
};

export default OdometerChart;