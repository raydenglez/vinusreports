import React from 'react';
import { useTranslation } from '../i18n/useTranslation';

interface LoginPageProps {
    onLogin: () => void;
    onBackToHome: () => void;
    onSignUpClick: () => void;
    onForgotPasswordClick: () => void;
    message?: string | null;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onBackToHome, onSignUpClick, onForgotPasswordClick, message }) => {
    const { t } = useTranslation();
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onLogin();
    }

    return (
        <div className="flex flex-col items-center justify-center py-12 animate-fade-in">
            <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-lg">
                <div className="text-center">
                    <h2 className="text-3xl font-bold text-gray-800">{t('loginPage.title')}</h2>
                    <p className="mt-2 text-gray-600">{t('loginPage.subtitle')}</p>
                </div>

                {message && (
                    <div className="mt-4 p-3 bg-green-50 border border-green-200 text-green-800 rounded-md text-sm text-center">
                        {message}
                    </div>
                )}
                
                <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
                    <div className="rounded-md shadow-sm -space-y-px">
                        <div>
                            <label htmlFor="email-address" className="sr-only">{t('loginPage.emailPlaceholder')}</label>
                            <input 
                                id="email-address" 
                                name="email" 
                                type="email" 
                                autoComplete="email" 
                                required 
                                className="appearance-none rounded-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm" 
                                placeholder={t('loginPage.emailPlaceholder')}
                                defaultValue="dealer@vinpro.com"
                            />
                        </div>
                        <div>
                            <label htmlFor="password" className="sr-only">{t('loginPage.passwordPlaceholder')}</label>
                            <input 
                                id="password" 
                                name="password" 
                                type="password" 
                                autoComplete="current-password" 
                                required 
                                className="appearance-none rounded-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm" 
                                placeholder={t('loginPage.passwordPlaceholder')}
                                defaultValue="password"
                            />
                        </div>
                    </div>

                    <div className="flex items-center justify-end">
                        <div className="text-sm">
                            <button type="button" onClick={onForgotPasswordClick} className="font-medium text-blue-600 hover:text-blue-500">
                                {t('loginPage.forgotPassword')}
                            </button>
                        </div>
                    </div>

                    <div>
                        <button 
                            type="submit" 
                            className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                            {t('loginPage.signIn')}
                        </button>
                    </div>
                </form>

                <div className="mt-6 text-center text-sm">
                    <p className="text-gray-600">
                        {t('loginPage.noAccount')}{' '}
                        <button onClick={onSignUpClick} className="font-medium text-blue-600 hover:text-blue-500">
                            {t('loginPage.signUp')}
                        </button>
                    </p>
                </div>
            </div>
            <button onClick={onBackToHome} className="mt-6 text-sm text-blue-600 hover:underline">
                {t('loginPage.backToHome')}
            </button>
        </div>
    );
};

export default LoginPage;
