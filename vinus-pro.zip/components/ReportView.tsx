import React, { useState } from 'react';
import type { VehicleReport, OdometerEvent, TitleAndBrand, Accident, Recall, TheftRecord, Complaint, ServiceBulletin } from '../types';
import ReportSummary from './ReportSummary';
import OdometerChart from './OdometerChart';
import Timeline from './Timeline';
import ReportSection from './ReportSection';
import VehicleSpecifications from './VehicleSpecifications';
import OwnershipCost from './OwnershipCost';
import UnlockOverlay from './UnlockOverlay';
import { currencyFormatter } from '../utils/formatters';
import { DownloadIcon, ShareIcon } from './icons/Icons';
import AuctionHistory from './report/AuctionHistory';
import ValueComparator from './report/ValueComparator';
import HistoricalPhotos from './report/HistoricalPhotos';
import ShareModal from './ShareModal';
import { useTranslation } from '../i18n/useTranslation';
import SafetyRatings from './report/SafetyRatings';

interface ReportViewProps {
  report: VehicleReport;
  onNewSearch: () => void;
  newSearchText?: string;
  isFreePreview?: boolean;
  onUnlockReport?: () => void;
  onSubscribe?: () => void;
}

const PremiumContent: React.FC<{ isFreePreview?: boolean; children: React.ReactNode; onUnlock: () => void; onSubscribe: () => void; }> = ({ isFreePreview, children, onUnlock, onSubscribe }) => {
    if (!isFreePreview) {
        return <>{children}</>;
    }
    return (
        <div className="relative rounded-lg overflow-hidden">
            <UnlockOverlay onUnlock={onUnlock} onSubscribe={onSubscribe} />
            <div className="filter blur-md pointer-events-none select-none opacity-50">
                {children}
            </div>
        </div>
    );
};


const ReportView: React.FC<ReportViewProps> = ({ 
    report, 
    onNewSearch, 
    newSearchText,
    isFreePreview = false,
    onUnlockReport = () => {},
    onSubscribe = () => {}
}) => {
  const { t } = useTranslation();
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  
  return (
    <div className="space-y-8 animate-fade-in">
      <ShareModal 
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        reportVin={report.vin}
      />
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">{t('reportView.title')}</h1>
        <div className="flex items-center space-x-4 print:hidden">
            {!isFreePreview && (
                <button
                    onClick={() => setIsShareModalOpen(true)}
                    className="bg-gray-200 text-gray-800 font-semibold py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors flex items-center"
                >
                    <ShareIcon className="h-5 w-5 mr-2" />
                    {t('reportView.shareReport')}
                </button>
            )}
            <button
              onClick={() => window.print()}
              disabled={isFreePreview}
              className="bg-gray-200 text-gray-800 font-semibold py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <DownloadIcon className="h-5 w-5 mr-2" />
              {t('reportView.downloadPdf')}
            </button>
            <button
              onClick={onNewSearch}
              className="bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
            >
              {newSearchText || t('reportView.newSearch')}
            </button>
        </div>
      </div>

      <ReportSummary report={report} isFreePreview={isFreePreview} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 print:block">
        <div className="lg:col-span-2 space-y-8 print:w-full">
            <PremiumContent isFreePreview={isFreePreview} onUnlock={onUnlockReport} onSubscribe={onSubscribe}>
              <div className="space-y-8">
                <ValueComparator report={report} />

                <Timeline<TitleAndBrand>
                    title={t('reportSections.titleHistory')}
                    items={report.titlesAndBrands}
                    dateKey="event_date"
                    emptyText={t('premiumData.titleHistory')}
                    renderContent={(item) => (
                        <div>
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${item.brand.toLowerCase().includes('clean') || item.brand.toLowerCase().includes('issued') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{item.brand}</span>
                            <p className="text-sm text-gray-600 mt-1">{item.state} DMV via {item.source}</p>
                        </div>
                    )}
                />

                <OdometerChart data={report.odometerEvents} />
                
                <AuctionHistory records={report.auctionHistory} />

                <ReportSection<Accident>
                    title={t('reportSections.accidentHistory')}
                    items={report.accidents}
                    emptyText={t('premiumData.accidentHistory')}
                    columns={[
                        { header: t('tableHeaders.date'), key: 'date', render: item => new Date(item.date).toLocaleDateString() },
                        { header: t('tableHeaders.severity'), key: 'severity' },
                        { header: t('tableHeaders.details'), key: 'damage_reported' },
                        { header: t('tableHeaders.source'), key: 'source' },
                    ]}
                />
                 <ReportSection<TheftRecord>
                    title={t('reportSections.theftHistory')}
                    items={report.theftRecords}
                    emptyText={t('premiumData.theftHistory')}
                    columns={[
                        { header: t('tableHeaders.date'), key: 'date', render: item => new Date(item.date).toLocaleDateString() },
                        { header: t('tableHeaders.status'), key: 'status' },
                        { header: t('tableHeaders.jurisdiction'), key: 'jurisdiction' },
                        { header: t('tableHeaders.source'), key: 'source' },
                    ]}
                />
              </div>
            </PremiumContent>
            
            <ReportSection<Recall>
                title={t('reportSections.recalls')}
                items={report.recalls}
                emptyText={t('recallItem.empty')}
                renderItem={(item) => (
                    <div className="p-6 border-b last:border-b-0">
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${item.status === 'open' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>{item.status}</span>
                        <p className="font-bold mt-2">{item.description}</p>
                        <p className="text-sm text-gray-600 mt-1">{t('recallItem.campaign')} {item.campaign_id} &middot; {t('recallItem.reported')} {new Date(item.date).toLocaleDateString()}</p>
                        <p className="text-sm text-gray-800 mt-2"><strong>{t('recallItem.remedy')}:</strong> {item.remedy}</p>
                    </div>
                )}
            />

            <ReportSection<Complaint>
                title={t('reportSections.complaints')}
                items={report.complaints}
                emptyText={t('complaints.empty')}
                columns={[
                    { header: t('tableHeaders.date'), key: 'date', render: item => new Date(item.date).toLocaleDateString() },
                    { header: t('tableHeaders.component'), key: 'component', className: 'whitespace-normal capitalize' },
                    { header: t('tableHeaders.summary'), key: 'summary', className: 'whitespace-normal max-w-sm' },
                    { header: t('tableHeaders.crashReported'), key: 'didCrash', render: item => item.didCrash ? <span className="font-bold text-red-600">Yes</span> : 'No' },
                ]}
            />
            
            <ReportSection<ServiceBulletin>
                title={t('reportSections.serviceBulletins')}
                items={report.serviceBulletins}
                emptyText={t('serviceBulletins.empty')}
                columns={[
                    { header: t('tableHeaders.date'), key: 'date', render: item => new Date(item.date).toLocaleDateString() },
                    { header: t('tableHeaders.component'), key: 'component', className: 'whitespace-normal capitalize' },
                    { header: t('tableHeaders.summary'), key: 'summary', className: 'whitespace-normal max-w-sm' },
                    { header: t('tableHeaders.bulletinId'), key: 'bulletinId' },
                ]}
            />

            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-bold mb-4">{t('reportView.dataSourcesTitle')}</h3>
              <ul className="text-sm text-gray-600 grid grid-cols-2 gap-x-4 gap-y-1">
                {report.providerAudit.map(p => <li key={p.provider} className="font-semibold">&bull; {p.provider}</li>)}
                <li>&bull; NMVTIS (Mock)</li>
                <li>&bull; Insurance Databases (Mock)</li>
                <li>&bull; Junk & Salvage Yards (Mock)</li>
              </ul>
            </div>
        </div>
        <div className="lg:col-span-1 space-y-8 print:w-full">
            <HistoricalPhotos photos={report.historicalPhotos} />
            <SafetyRatings rating={report.safetyRating} />
            <OwnershipCost cost={report.ownershipCost} />
            <VehicleSpecifications specs={report.vehicleSpecs} fuelType={report.fuel} />
        </div>
      </div>
    </div>
  );
};

export default ReportView;