


export interface SafetyRating {
  overallRating: string;
  frontalCrash: string;
  sideCrash: string;
  rollover: string;
  reportUrl: string;
}

export interface Complaint {
  date: string;
  component: string;
  summary: string;
  complaintId: string;
  didCrash: boolean;
}

export interface ServiceBulletin {
  date: string;
  component: string;
  summary: string;
  bulletinId: string;
}

export interface VehicleReport {
  id: string;
  vin: string;
  year: number;
  make: string;
  model: string;
  trim: string;
  body: string;
  engine: string;
  drivetrain: string;
  fuel: string;
  color: string;
  assembly_plant: string;
  decoded_at: string;
  vehicleSpecs: VehicleSpecs;
  ownershipCost: OwnershipCost;
  titlesAndBrands: TitleAndBrand[];
  odometerEvents: OdometerEvent[];
  accidents: Accident[];
  theftRecords: TheftRecord[];
  recalls: Recall[];
  complaints: Complaint[];
  serviceBulletins: ServiceBulletin[];
  serviceRecords: ServiceRecord[];
  ownershipHistory: OwnershipHistory[];
  marketValuation: MarketValuation;
  scorecard: Scorecard;
  providerAudit: ProviderAudit[];
  // New Features
  auctionHistory: AuctionRecord[];
  valuationSources: ValuationSource[];
  historicalPhotos: HistoricalPhoto[];
  liveMarketListings: LiveMarketListing[];
  safetyRating: SafetyRating | null;
}

export interface VehicleSpecs {
    mpg_city: number;
    mpg_highway: number;
    horsepower: number;
    torque_ft_lbs: number;
    curb_weight_lbs: number;
    length_in: number;
    width_in: number;
    height_in: number;
}

export interface OwnershipCost {
    five_year_total: number;
    maintenance: number;
    fuel: number;
    insurance: number;
}

export interface TitleAndBrand {
  event_date: string;
  state: string;
  brand: string;
  source: string;
}

export interface OdometerEvent {
  date: string;
  reading: number;
  unit: 'miles' | 'km';
  source: string;
  flagged_rollback?: boolean;
}

export interface Accident {
  date: string;
  type: 'collision' | 'fire' | 'flood' | 'hail' | 'other';
  severity: 'minor' | 'moderate' | 'severe';
  source: string;
  airbag_deployed: boolean;
  damage_reported: string;
  location?: string;
}

export interface TheftRecord {
  date: string;
  status: 'reported stolen' | 'recovered';
  jurisdiction: string;
  source: string;
}

export interface Recall {
  date: string;
  campaign_id: string;
  description: string;
  remedy: string;
  status: 'open' | 'remedied';
}

export interface ServiceRecord {
  date: string;
  description: string;
  dealer_name: string;
  location: string;
}

export interface OwnershipHistory {
  sequence_no: number;
  start_date: string;
  end_date: string | null;
  type: 'personal' | 'fleet' | 'rental' | 'commercial' | 'lease';
  state: string;
}

export interface MarketValuation {
  retail: number;
  trade_in: number;
  private_party: number;
  confidence: 'high' | 'medium' | 'low';
}

export interface Scorecard {
  transparency_score: number;
  risk_flags: string[];
  highlights: string[];
}

export interface ProviderAudit {
  provider: string;
  started_at: string;
  finished_at: string;
  status: 'ok' | 'error';
  api_units_used?: number;
}

export type BillingCycle = 'monthly' | 'yearly';

// This represents the object passed to checkout and stored in app state
export interface SelectedPlan {
    name: string;
    price: number;
    billingCycle: BillingCycle;
    priceSuffix: string;
    features: string[];
}

// This represents the user's current subscription in the portal
export interface UserSubscription {
    planName: string; // "Pro Dealer"
    billingCycle: BillingCycle;
    status: 'active' | 'canceled';
    nextBillingDate: string;
    reportsUsed: number;
    reportsIncluded: number;
    price: number;
}

// --- NEW TYPES ---
export interface AuctionRecord {
  date: string;
  source: 'Copart' | 'IAAI' | 'Manheim' | 'Adesa';
  location: string;
  hammer_price: number | 'N/A';
  odometer: number;
  title_type: string;
  source_url?: string;
}

export interface ValuationSource {
  provider: 'KBB' | 'NADA' | 'Black Book';
  retail: number;
  trade_in: number;
}

export interface HistoricalPhoto {
  url: string;
  source: string;
  date: string;
  description: string;
}

export interface LiveMarketListing {
  source: string;
  price: number;
  mileage: number;
  location: string;
  url: string;
  notes?: string;
}