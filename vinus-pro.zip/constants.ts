import type { VehicleReport } from './types';

export const HONDA_ACCORD_VIN = '1HGCM82637A123456';
export const FORD_F150_VIN = '1FTFW1E8XGKA12345';
export const TESLA_MODEL3_VIN = '5YJ3E1EA0KF123456';
export const JEEP_WRANGLER_VIN = '1C4HJXDN6LW123456';

export const EXAMPLE_VINS = [
  { vin: HONDA_ACCORD_VIN, name: 'Honda Accord' },
  { vin: FORD_F150_VIN, name: 'Ford F-150' },
  { vin: TESLA_MODEL3_VIN, name: 'Tesla Model 3' },
  { vin: JEEP_WRANGLER_VIN, name: 'Jeep Wrangler' },
];


export const MOCK_HONDA_ACCORD_REPORT: VehicleReport = {
  id: 'rep_honda_123',
  vin: HONDA_ACCORD_VIN,
  year: 2017,
  make: 'Honda',
  model: 'Accord',
  trim: 'EX-L',
  body: 'Sedan',
  engine: '2.4L I4',
  drivetrain: 'FWD',
  fuel: 'Gasoline',
  color: 'White Orchid Pearl',
  assembly_plant: 'Marysville, Ohio',
  decoded_at: new Date().toISOString(),
  vehicleSpecs: {
    mpg_city: 27,
    mpg_highway: 36,
    horsepower: 185,
    torque_ft_lbs: 181,
    curb_weight_lbs: 3349,
    length_in: 192.5,
    width_in: 72.8,
    height_in: 57.7,
  },
  ownershipCost: {
    five_year_total: 28500,
    maintenance: 4500,
    fuel: 12000,
    insurance: 12000,
  },
  scorecard: {
    transparency_score: 88,
    risk_flags: [
      'Odometer Rollback Detected',
      '1 Open Recall',
    ],
    highlights: [
      'Clean Title History',
      'No Accidents Reported',
    ],
  },
  titlesAndBrands: [
    { event_date: '2022-08-15', state: 'CA', brand: 'Clean Title', source: 'CA DMV' },
    { event_date: '2019-05-20', state: 'AZ', brand: 'Clean Title', source: 'AZ MVD' },
    { event_date: '2017-02-10', state: 'AZ', brand: 'Title Issued', source: 'AZ MVD' },
  ],
  odometerEvents: [
    { date: '2023-09-01', reading: 75200, unit: 'miles', source: 'Service Record' },
    { date: '2022-08-15', reading: 65100, unit: 'miles', source: 'Title Transfer' },
    { date: '2022-07-20', reading: 72300, unit: 'miles', source: 'Oil Change', flagged_rollback: true },
    { date: '2021-08-10', reading: 54300, unit: 'miles', source: 'Emissions Test' },
    { date: '2019-05-20', reading: 32500, unit: 'miles', source: 'Title Transfer' },
  ],
  accidents: [],
  theftRecords: [],
  recalls: [
    {
      date: '2020-05-18',
      campaign_id: 'NHTSA20V314000',
      description: 'Fuel Pump Motor May Fail',
      remedy: 'The remedy is to replace the fuel pump module. The recall began November 9, 2020.',
      status: 'open',
    },
    {
      date: '2019-01-09',
      campaign_id: 'NHTSA19V000000',
      description: 'Software Update for TCU',
      remedy: 'Dealers will reprogram the TCU software, free of charge.',
      status: 'remedied',
    },
  ],
  complaints: [
    {
      date: '2021-06-22',
      component: 'ELECTRICAL SYSTEM',
      summary: 'While driving approximately 30 mph, the vehicle stalled without warning. The driver was able to restart the vehicle after several attempts. The failure recurred multiple times. The dealer was unable to diagnose the failure.',
      complaintId: '11423456',
      didCrash: false,
    },
    {
      date: '2020-11-10',
      component: 'ENGINE',
      summary: 'The vehicle hesitates and sputters upon acceleration from a stop. This issue is intermittent and the check engine light does not illuminate. The dealer has not been able to replicate the issue.',
      complaintId: '11387654',
      didCrash: false,
    },
  ],
  serviceBulletins: [
    {
      date: '2018-03-01',
      component: 'POWER TRAIN:AUTOMATIC TRANSMISSION',
      summary: 'Service bulletin regarding a software update to improve transmission shift quality and address a potential judder condition under light acceleration.',
      bulletinId: 'A18-024',
    },
  ],
  serviceRecords: [
    { date: '2023-09-01', description: '75,000 Mile Service, Replaced Front Brake Pads', dealer_name: 'Honda of Downtown', location: 'Los Angeles, CA' },
    { date: '2022-07-20', description: 'Oil and Filter Change', dealer_name: 'Jiffy Lube', location: 'Phoenix, AZ' },
  ],
  ownershipHistory: [
    { sequence_no: 3, start_date: '2022-08-15', end_date: null, type: 'personal', state: 'CA' },
    { sequence_no: 2, start_date: '2019-05-20', end_date: '2022-08-14', type: 'personal', state: 'AZ' },
    { sequence_no: 1, start_date: '2017-02-10', end_date: '2019-05-19', type: 'lease', state: 'AZ' },
  ],
  marketValuation: {
    retail: 18500,
    trade_in: 16200,
    private_party: 17800,
    confidence: 'high',
  },
  providerAudit: [
    { provider: 'NHTSA', started_at: '2024-01-01T12:00:01Z', finished_at: '2024-01-01T12:00:02Z', status: 'ok' },
    { provider: 'VinAudit', started_at: '2024-01-01T12:00:02Z', finished_at: '2024-01-01T12:00:04Z', status: 'ok', api_units_used: 1 },
    { provider: 'National Insurance DB', started_at: '2024-01-01T12:00:04Z', finished_at: '2024-01-01T12:00:05Z', status: 'ok' },
    { provider: 'Auction History DB', started_at: '2024-01-01T12:00:05Z', finished_at: '2024-01-01T12:00:06Z', status: 'ok' },
  ],
  auctionHistory: [
    { date: '2022-08-10', source: 'Manheim', location: 'Riverside, CA', hammer_price: 15500, odometer: 64800, title_type: 'Clean', source_url: '#' },
    { date: '2019-05-15', source: 'Adesa', location: 'Phoenix, AZ', hammer_price: 17200, odometer: 32300, title_type: 'Clean', source_url: '#' },
  ],
  valuationSources: [
    { provider: 'KBB', retail: 18900, trade_in: 16500 },
    { provider: 'NADA', retail: 19250, trade_in: 16800 },
    { provider: 'Black Book', retail: 18700, trade_in: 16300 },
  ],
  historicalPhotos: [
    { url: 'https://picsum.photos/800/600?random=1', source: 'Dealer Listing', date: '2022-08-15', description: 'Front view at dealership.' },
    { url: 'https://picsum.photos/800/600?random=5', source: 'Manheim Auction', date: '2022-08-10', description: 'Side view, auction block #3.' },
    { url: 'https://picsum.photos/800/600?random=6', source: 'Adesa Auction', date: '2019-05-15', description: 'Interior shot, pre-detailing.' },
  ],
  liveMarketListings: [
    { source: 'OfferUp', price: 18995, mileage: 72000, location: 'Los Angeles, CA', url: '#', notes: 'Listed 2 days ago' },
    { source: 'Local Honda Dealer', price: 19500, mileage: 68500, location: 'Pasadena, CA', url: '#', notes: 'Certified Pre-Owned' },
    { source: 'Craigslist', price: 17800, mileage: 81000, location: 'Irvine, CA', url: '#', notes: 'Private seller, OBO' },
    { source: 'Cars.com', price: 19250, mileage: 71500, location: 'Glendale, CA', url: '#', notes: 'Fleet vehicle' },
  ],
  safetyRating: {
    overallRating: '5',
    frontalCrash: '5',
    sideCrash: '5',
    rollover: '5',
    reportUrl: 'https://www.nhtsa.gov/vehicle/2017/HONDA/ACCORD/4%252520DR/FWD',
  },
};

export const MOCK_FORD_F150_REPORT: VehicleReport = {
  id: 'rep_ford_456',
  vin: FORD_F150_VIN,
  year: 2018,
  make: 'Ford',
  model: 'F-150',
  trim: 'Lariat',
  body: 'SuperCrew Cab',
  engine: '3.5L V6 EcoBoost',
  drivetrain: '4WD',
  fuel: 'Gasoline',
  color: 'Magnetic Metallic',
  assembly_plant: 'Dearborn, Michigan',
  decoded_at: new Date().toISOString(),
  vehicleSpecs: {
    mpg_city: 17,
    mpg_highway: 23,
    horsepower: 375,
    torque_ft_lbs: 470,
    curb_weight_lbs: 4917,
    length_in: 231.9,
    width_in: 79.9,
    height_in: 77.2,
  },
  ownershipCost: {
    five_year_total: 39500,
    maintenance: 6500,
    fuel: 18000,
    insurance: 15000,
  },
  scorecard: {
    transparency_score: 79,
    risk_flags: [
      'Minor Accident Reported',
      'Commercial Use History',
    ],
    highlights: [
      'Clean Title History',
      'No Odometer Issues',
      '1 Owner Vehicle',
    ],
  },
  titlesAndBrands: [
    { event_date: '2018-03-20', state: 'MI', brand: 'Title Issued', source: 'MI SOS' },
  ],
  odometerEvents: [
    { date: '2023-06-12', reading: 98500, unit: 'miles', source: 'Auction Record' },
    { date: '2022-04-01', reading: 82100, unit: 'miles', source: 'Service Record' },
    { date: '2020-03-15', reading: 45300, unit: 'miles', source: 'Lease Return' },
  ],
  accidents: [
    { date: '2021-11-05', type: 'collision', severity: 'minor', source: 'Insurance Claim', airbag_deployed: false, damage_reported: 'Minor front bumper damage', location: 'Detroit, MI' },
  ],
  theftRecords: [],
  recalls: [],
  complaints: [
      {
          date: '2022-01-15',
          component: 'POWER TRAIN',
          summary: 'Vehicle experiences harsh shifting between gears, particularly when cold. Dealer performed a software update which did not resolve the issue completely.',
          complaintId: '11451234',
          didCrash: false,
      }
  ],
  serviceBulletins: [],
  serviceRecords: [
    { date: '2022-04-01', description: 'Scheduled Maintenance, Tire Rotation', dealer_name: 'Ford of Dearborn', location: 'Dearborn, MI' },
  ],
  ownershipHistory: [
    { sequence_no: 1, start_date: '2018-03-20', end_date: null, type: 'commercial', state: 'MI' },
  ],
  marketValuation: {
    retail: 34000,
    trade_in: 31500,
    private_party: 33000,
    confidence: 'medium',
  },
  providerAudit: [
     { provider: 'NHTSA', started_at: '2024-01-01T12:00:01Z', finished_at: '2024-01-01T12:00:02Z', status: 'ok' },
     { provider: 'AutoDataDirect', started_at: '2024-01-01T12:00:02Z', finished_at: '2024-01-01T12:00:04Z', status: 'ok', api_units_used: 1 },
     { provider: 'National Insurance DB', started_at: '2024-01-01T12:00:04Z', finished_at: '2024-01-01T12:00:05Z', status: 'ok' },
     { provider: 'Auction History DB', started_at: '2024-01-01T12:00:05Z', finished_at: '2024-01-01T12:00:06Z', status: 'ok' },
  ],
  auctionHistory: [],
  valuationSources: [
    { provider: 'KBB', retail: 34500, trade_in: 31800 },
    { provider: 'NADA', retail: 34200, trade_in: 31600 },
    { provider: 'Black Book', retail: 33800, trade_in: 31200 },
  ],
  historicalPhotos: [
    { url: 'https://picsum.photos/800/600?random=2', source: 'Auction Listing', date: '2023-06-12', description: 'Vehicle at auction.' },
  ],
  liveMarketListings: [
    { source: 'Ford Dealer', price: 35500, mileage: 95000, location: 'Dearborn, MI', url: '#', notes: 'Recent trade-in' },
    { source: 'Facebook Marketplace', price: 33000, mileage: 105000, location: 'Ann Arbor, MI', url: '#', notes: 'Well-maintained' },
  ],
  safetyRating: {
    overallRating: '5',
    frontalCrash: '5',
    sideCrash: '5',
    rollover: '4',
    reportUrl: 'https://www.nhtsa.gov/vehicle/2018/FORD/F-150/SUPERCAB/4WD',
  },
};

export const MOCK_TESLA_MODEL3_REPORT: VehicleReport = {
  id: 'rep_tesla_789',
  vin: TESLA_MODEL3_VIN,
  year: 2021,
  make: 'Tesla',
  model: 'Model 3',
  trim: 'Standard Range Plus',
  body: 'Sedan',
  engine: 'Electric',
  drivetrain: 'RWD',
  fuel: 'Electric',
  color: 'Pearl White Multi-Coat',
  assembly_plant: 'Fremont, California',
  decoded_at: new Date().toISOString(),
  vehicleSpecs: {
    mpg_city: 142, // MPGe
    mpg_highway: 123, // MPGe
    horsepower: 283,
    torque_ft_lbs: 330,
    curb_weight_lbs: 3582,
    length_in: 184.8,
    width_in: 72.8,
    height_in: 56.8,
  },
  ownershipCost: {
    five_year_total: 25000,
    maintenance: 3000,
    fuel: 4000, // Electricity cost
    insurance: 18000,
  },
  scorecard: {
    transparency_score: 98,
    risk_flags: [],
    highlights: [
      'Clean Title History',
      'No Accidents Reported',
      'No Odometer Issues',
      '1-Owner Personal Vehicle',
    ],
  },
  titlesAndBrands: [
    { event_date: '2021-07-10', state: 'CA', brand: 'Title Issued', source: 'CA DMV' },
  ],
  odometerEvents: [
    { date: '2023-10-01', reading: 22000, unit: 'miles', source: 'Service Record' },
    { date: '2022-07-15', reading: 11500, unit: 'miles', source: 'Annual Checkup' },
  ],
  accidents: [],
  theftRecords: [],
  recalls: [
    { date: '2022-05-20', campaign_id: 'TESLA22V123', description: 'Infotainment System Overheating', remedy: 'Over-the-air (OTA) software update was deployed.', status: 'remedied' },
  ],
  complaints: [],
  serviceBulletins: [
      {
          date: '2022-02-10',
          component: 'ELECTRICAL SYSTEM',
          summary: 'Technical Service Bulletin regarding replacement of the 12V low voltage battery if it fails a health test during service.',
          bulletinId: 'SB-22-17-004',
      }
  ],
  serviceRecords: [
     { date: '2023-10-01', description: 'Replaced cabin air filter, tire rotation', dealer_name: 'Tesla Service Center', location: 'Palo Alto, CA' },
  ],
  ownershipHistory: [
    { sequence_no: 1, start_date: '2021-07-10', end_date: null, type: 'personal', state: 'CA' },
  ],
  marketValuation: {
    retail: 39000,
    trade_in: 36000,
    private_party: 38000,
    confidence: 'high',
  },
  providerAudit: [
    { provider: 'NHTSA', started_at: '2024-01-01T12:00:01Z', finished_at: '2024-01-01T12:00:02Z', status: 'ok' },
    { provider: 'VinAudit', started_at: '2024-01-01T12:00:02Z', finished_at: '2024-01-01T12:00:04Z', status: 'ok', api_units_used: 1 },
    { provider: 'National Insurance DB', started_at: '2024-01-01T12:00:04Z', finished_at: '2024-01-01T12:00:05Z', status: 'ok' },
    { provider: 'Auction History DB', started_at: '2024-01-01T12:00:05Z', finished_at: '2024-01-01T12:00:06Z', status: 'ok' },
  ],
  auctionHistory: [],
  valuationSources: [
    { provider: 'KBB', retail: 39500, trade_in: 36200 },
    { provider: 'NADA', retail: 39100, trade_in: 36000 },
    { provider: 'Black Book', retail: 38800, trade_in: 35700 },
  ],
  historicalPhotos: [
    { url: 'https://picsum.photos/800/600?random=3', source: 'Owner Listing', date: '2023-11-01', description: 'Original owner sale listing photo.' },
  ],
  liveMarketListings: [
    { source: 'Tesla CPO', price: 40500, mileage: 21000, location: 'Fremont, CA', url: '#', notes: 'Includes FSD Beta' },
    { source: 'Autotrader', price: 38500, mileage: 25000, location: 'San Jose, CA', url: '#', notes: 'Excellent condition' },
    { source: 'Craigslist', price: 37000, mileage: 28000, location: 'Palo Alto, CA', url: '#', notes: 'Private seller' },
  ],
  safetyRating: {
    overallRating: '5',
    frontalCrash: '5',
    sideCrash: '5',
    rollover: '5',
    reportUrl: 'https://www.nhtsa.gov/vehicle/2021/TESLA/MODEL%2525203/RWD',
  },
};

export const MOCK_JEEP_WRANGLER_REPORT: VehicleReport = {
  id: 'rep_jeep_999',
  vin: JEEP_WRANGLER_VIN,
  year: 2020,
  make: 'Jeep',
  model: 'Wrangler',
  trim: 'Rubicon',
  body: 'SUV',
  engine: '3.6L V6',
  drivetrain: '4WD',
  fuel: 'Gasoline',
  color: 'Bikini Pearlcoat',
  assembly_plant: 'Toledo, Ohio',
  decoded_at: new Date().toISOString(),
  vehicleSpecs: {
    mpg_city: 17,
    mpg_highway: 23,
    horsepower: 285,
    torque_ft_lbs: 260,
    curb_weight_lbs: 4439,
    length_in: 188.4,
    width_in: 73.8,
    height_in: 73.6,
  },
  ownershipCost: {
    five_year_total: 42000,
    maintenance: 7000,
    fuel: 19000,
    insurance: 16000,
  },
  scorecard: {
    transparency_score: 65,
    risk_flags: [
      'Rebuilt Title Issued',
      'Theft & Recovery Reported',
      'Moderate Accident Reported',
    ],
    highlights: [
      'No Odometer Issues',
      'All Recalls Remeded',
    ],
  },
  titlesAndBrands: [
    { event_date: '2023-01-15', state: 'FL', brand: 'Rebuilt Title', source: 'FL DHSMV' },
    { event_date: '2022-10-05', state: 'FL', brand: 'Salvage Title', source: 'FL DHSMV' },
    { event_date: '2020-04-10', state: 'FL', brand: 'Title Issued', source: 'FL DHSMV' },
  ],
  odometerEvents: [
    { date: '2023-01-15', reading: 35100, unit: 'miles', source: 'Title Transfer' },
    { date: '2022-09-20', reading: 33500, unit: 'miles', source: 'Insurance Claim' },
    { date: '2021-04-12', reading: 15200, unit: 'miles', source: 'Service Record' },
  ],
  accidents: [
      { date: '2022-09-20', type: 'collision', severity: 'moderate', source: 'Police Report', airbag_deployed: true, damage_reported: 'Front-end damage, vehicle towed', location: 'Miami, FL'},
  ],
  theftRecords: [
      { date: '2022-07-01', status: 'reported stolen', jurisdiction: 'Miami-Dade Police', source: 'Law Enforcement' },
      { date: '2022-07-05', status: 'recovered', jurisdiction: 'Miami-Dade Police', source: 'Law Enforcement' },
  ],
  recalls: [],
  complaints: [
      {
          date: '2021-08-01',
          component: 'STEERING',
          summary: 'Excessive play in the steering wheel, requiring constant correction to keep the vehicle straight at highway speeds. Known as the "death wobble" by the community.',
          complaintId: '11430011',
          didCrash: true,
      }
  ],
  serviceBulletins: [],
  serviceRecords: [
     { date: '2023-02-20', description: 'Post-rebuild state inspection', dealer_name: 'FL State Inspection Center', location: 'Tampa, FL' },
     { date: '2021-04-12', description: '15,000 mile service', dealer_name: 'Jeep of Miami', location: 'Miami, FL' },
  ],
  ownershipHistory: [
    { sequence_no: 2, start_date: '2023-01-15', end_date: null, type: 'personal', state: 'FL' },
    { sequence_no: 1, start_date: '2020-04-10', end_date: '2022-10-05', type: 'personal', state: 'FL' },
  ],
  marketValuation: {
    retail: 31000,
    trade_in: 28000,
    private_party: 30000,
    confidence: 'medium',
  },
  providerAudit: [
    { provider: 'NHTSA', started_at: '2024-01-01T12:00:01Z', finished_at: '2024-01-01T12:00:02Z', status: 'ok' },
    { provider: 'AutoDataDirect', started_at: '2024-01-01T12:00:02Z', finished_at: '2024-01-01T12:00:04Z', status: 'ok', api_units_used: 1 },
    { provider: 'National Insurance DB', started_at: '2024-01-01T12:00:04Z', finished_at: '2024-01-01T12:00:05Z', status: 'ok' },
    { provider: 'Auction History DB', started_at: '2024-01-01T12:00:05Z', finished_at: '2024-01-01T12:00:06Z', status: 'ok' },
  ],
  auctionHistory: [
    { date: '2022-10-01', source: 'Copart', location: 'Miami, FL', hammer_price: 18000, odometer: 33600, title_type: 'Salvage', source_url: '#' },
    { date: '2022-09-28', source: 'IAAI', location: 'Miami, FL', hammer_price: 'N/A', odometer: 33550, title_type: 'Salvage', source_url: '#' },
  ],
  valuationSources: [
    { provider: 'KBB', retail: 31500, trade_in: 28300 },
    { provider: 'NADA', retail: 31200, trade_in: 28100 },
    { provider: 'Black Book', retail: 30900, trade_in: 27900 },
  ],
  historicalPhotos: [
    { url: 'https://picsum.photos/800/600?random=4', source: 'Insurance Auction', date: '2022-10-01', description: 'Vehicle at Copart auction after accident.' },
  ],
  liveMarketListings: [
      { source: 'Jeep Dealer', price: 32000, mileage: 34000, location: 'Miami, FL', url: '#', notes: 'Rebuilt title, professionally repaired' },
      { source: 'OfferUp', price: 29500, mileage: 41000, location: 'Fort Lauderdale, FL', url: '#', notes: 'Rebuilt, sold as-is' },
  ],
  safetyRating: {
    overallRating: 'Not Rated',
    frontalCrash: '4',
    sideCrash: 'Not Rated',
    rollover: '3',
    reportUrl: 'https://www.nhtsa.gov/vehicle/2020/JEEP/WRANGLER%2525204WD/SUV/4%252520DR',
  },
};

export const MOCK_REPORTS_BY_VIN: { [key: string]: VehicleReport } = {
  [HONDA_ACCORD_VIN]: MOCK_HONDA_ACCORD_REPORT,
  [FORD_F150_VIN]: MOCK_FORD_F150_REPORT,
  [TESLA_MODEL3_VIN]: MOCK_TESLA_MODEL3_REPORT,
  [JEEP_WRANGLER_VIN]: MOCK_JEEP_WRANGLER_REPORT,
};

export const MOCK_DEALER_INVENTORY = Object.values(MOCK_REPORTS_BY_VIN);