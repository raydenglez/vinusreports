import type { VehicleReport, LiveMarketListing, Recall, SafetyRating, Complaint, ServiceBulletin } from '../types';
import { MOCK_REPORTS_BY_VIN } from '../constants';
import { validateVin } from '../utils/vinValidator';

// This will be the base for historical data for any VIN not in our premium mock set
const createGenericReport = (vin: string): VehicleReport => {
    const basePrice = 22000;
    return {
      id: `rep_generic_${Date.now()}`,
      vin: vin.toUpperCase(),
      year: 2020,
      make: 'Unknown',
      model: 'Unknown',
      trim: 'N/A',
      body: 'N/A',
      engine: 'N/A',
      drivetrain: 'N/A',
      fuel: 'N/A',
      color: 'N/A',
      assembly_plant: 'N/A',
      decoded_at: new Date().toISOString(),
      vehicleSpecs: {
        mpg_city: 0,
        mpg_highway: 0,
        horsepower: 0,
        torque_ft_lbs: 0,
        curb_weight_lbs: 0,
        length_in: 0,
        width_in: 0,
        height_in: 0,
      },
      ownershipCost: {
        five_year_total: 31000,
        maintenance: 5000,
        fuel: 13000,
        insurance: 13000,
      },
      scorecard: {
        transparency_score: 95,
        risk_flags: [],
        highlights: ['Basic Vehicle Data from NHTSA'],
      },
      titlesAndBrands: [],
      odometerEvents: [],
      accidents: [],
      theftRecords: [],
      recalls: [],
      complaints: [],
      serviceBulletins: [],
      serviceRecords: [],
      ownershipHistory: [],
      marketValuation: { retail: basePrice, trade_in: 19500, private_party: 21000, confidence: 'medium' },
      providerAudit: [
        { provider: 'NHTSA vPIC', started_at: new Date().toISOString(), finished_at: new Date().toISOString(), status: 'ok' },
        { provider: 'NHTSA Recalls API', started_at: new Date().toISOString(), finished_at: new Date().toISOString(), status: 'ok' },
        { provider: 'NHTSA Safety Ratings API', started_at: new Date().toISOString(), finished_at: new Date().toISOString(), status: 'ok' },
        { provider: 'NHTSA Complaints API', started_at: new Date().toISOString(), finished_at: new Date().toISOString(), status: 'ok' },
        { provider: 'NHTSA TSBs API', started_at: new Date().toISOString(), finished_at: new Date().toISOString(), status: 'ok' },
      ],
      auctionHistory: [],
      valuationSources: [],
      historicalPhotos: [],
      liveMarketListings: [],
      safetyRating: null,
    };
};

async function decodeVinFromNhtsa(vin: string): Promise<Partial<VehicleReport>> {
  const url = `https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValuesExtended/${vin}?format=json`;
  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.Count === 0 || !data.Results || data.Results.length === 0) {
      throw new Error(data.Message || 'VIN not found or invalid.');
    }
    
    const result = data.Results[0];
    const findValue = (key: string) => (result[key] || '').trim();
    const errorCode = findValue('ErrorCode');
    const errorText = findValue('ErrorText');

    if (errorCode !== '0' && errorCode !== '') {
        if (errorText && !errorText.toLowerCase().includes('success')) {
            throw new Error(errorText);
        }
    }
    
    if (errorText && (errorText.toLowerCase().includes('vin is not valid') || errorText.toLowerCase().includes('vin decoding is not available'))) {
        throw new Error(errorText);
    }
    
    const year = parseInt(findValue('ModelYear'), 10);
    const hp = parseInt(findValue('EngineHP'), 10);
    const torque = parseInt(findValue('EngineTorque'), 10);
    const cityMpg = parseInt(findValue('CityMPG'), 10);
    const highwayMpg = parseInt(findValue('HighwayMPG'), 10);
    const curbWeight = parseInt(findValue('CurbWeightLB'), 10);
    const length = parseFloat(findValue('OverallLength'));
    const width = parseFloat(findValue('OverallWidth'));
    const height = parseFloat(findValue('OverallHeight'));
    
    const engineCyl = findValue('EngineCylinders');
    const engineL = findValue('DisplacementL');
    const engineParts: string[] = [];
    if (engineCyl && engineCyl !== '0') engineParts.push(`${engineCyl} Cyl`);
    if (engineL && engineL !== '0.0') engineParts.push(`${engineL}L`);
    const engine = engineParts.join(', ') || 'N/A';
    
    const plantCity = findValue('PlantCity');
    const plantState = findValue('PlantState');
    const plantParts: string[] = [];
    if(plantCity) plantParts.push(plantCity);
    if(plantState) plantParts.push(plantState);
    const assemblyPlant = plantParts.join(', ');

    const decodedData: Partial<VehicleReport> & { vehicleSpecs: Partial<VehicleReport['vehicleSpecs']> } = {
      vin: findValue('VIN') || vin,
      year: isNaN(year) ? 0 : year,
      make: findValue('Make'),
      model: findValue('Model'),
      trim: findValue('Trim') || 'N/A',
      body: findValue('BodyClass'),
      engine: engine,
      drivetrain: findValue('DriveType'),
      fuel: findValue('FuelTypePrimary'),
      assembly_plant: assemblyPlant,
      vehicleSpecs: {
          mpg_city: isNaN(cityMpg) ? 0 : cityMpg,
          mpg_highway: isNaN(highwayMpg) ? 0 : highwayMpg,
          horsepower: isNaN(hp) ? 0 : hp,
          torque_ft_lbs: isNaN(torque) ? 0 : torque,
          curb_weight_lbs: isNaN(curbWeight) ? 0 : curbWeight,
          length_in: isNaN(length) ? 0 : length,
          width_in: isNaN(width) ? 0 : width,
          height_in: isNaN(height) ? 0 : height,
      }
    };
    return decodedData;
  } catch (error) {
    console.error("NHTSA API Error:", error);
    if (error instanceof Error) {
        if (error.message.includes('fetch')) {
             throw new Error("Could not connect to the vehicle data service. Please check your network connection.");
        }
        throw error;
    }
    throw new Error('An unknown error occurred while decoding the VIN.');
  }
}

// Helper to parse NHTSA dates (MM/DD/YYYY)
const parseNhtsaDate = (dateStr: string): string => {
    if (!dateStr || typeof dateStr !== 'string') return new Date(0).toISOString();
    const dateParts = dateStr.split('/');
    if (dateParts.length !== 3) return new Date(0).toISOString();
    return new Date(parseInt(dateParts[2]), parseInt(dateParts[0]) - 1, parseInt(dateParts[1])).toISOString();
};

async function getRecallsByVin(vin: string): Promise<Recall[]> {
  const url = `https://api.nhtsa.gov/recalls/v2/by-vin/${vin}?format=json`;
  try {
    const response = await fetch(url);
    if (!response.ok) {
      console.error(`NHTSA Recalls API request failed with status: ${response.status}`);
      return [];
    }
    const data = await response.json();
    if (data.Count > 0 && Array.isArray(data.Results)) {
      return data.Results.map((recall: any): Recall => ({
          date: parseNhtsaDate(recall.ReportReceivedDate),
          campaign_id: recall.NHTSACampaignNumber,
          description: recall.Summary,
          remedy: recall.Remedy,
          status: 'open',
      }));
    }
    return [];
  } catch (error) {
    console.error("NHTSA Recalls API Error:", error);
    return [];
  }
}

async function getComplaintsByVin(vin: string): Promise<Complaint[]> {
  const url = `https://api.nhtsa.gov/complaints/v2/by-vin/${vin}?format=json`;
  try {
    const response = await fetch(url);
    if (!response.ok) {
      console.error(`NHTSA Complaints API request failed with status: ${response.status}`);
      return [];
    }
    const data = await response.json();
    if (data.Count > 0 && Array.isArray(data.Results)) {
      return data.Results.map((c: any): Complaint => ({
        date: parseNhtsaDate(c.DATE_OF_INCIDENT),
        component: c.AFFECTED_COMPONENTS,
        summary: c.SUMMARY,
        complaintId: c.COMPLAINT_TBN,
        didCrash: c.CRASH === 'Yes',
      }));
    }
    return [];
  } catch (error) {
    console.error("NHTSA Complaints API Error:", error);
    return [];
  }
}

async function getServiceBulletinsByVin(vin: string): Promise<ServiceBulletin[]> {
  const url = `https://api.nhtsa.gov/tsbs/v2/by-vin/${vin}?format=json`;
  try {
    const response = await fetch(url);
    if (!response.ok) {
      console.error(`NHTSA TSBs API request failed with status: ${response.status}`);
      return [];
    }
    const data = await response.json();
    if (data.Count > 0 && Array.isArray(data.Results)) {
      return data.Results.map((tsb: any): ServiceBulletin => ({
        date: parseNhtsaDate(tsb.DATE_OF_ISSUE),
        component: tsb.AFFECTED_COMPONENTS,
        summary: tsb.SUMMARY,
        bulletinId: tsb.TSB_TBN,
      }));
    }
    return [];
  } catch (error) {
    console.error("NHTSA TSBs API Error:", error);
    return [];
  }
}

async function getSafetyRatings(year: number, make: string, model: string): Promise<SafetyRating | null> {
    if (!year || !make || !model) {
        return null;
    }
    try {
        const modelUrl = `https://api.nhtsa.gov/SafetyRatings/collections/Vehicle/modelyear/${year}/make/${make}/model/${model}?format=json`;
        const modelResponse = await fetch(modelUrl);
        if (!modelResponse.ok) return null;

        const modelData = await modelResponse.json();
        const vehicleId = modelData.Results[0]?.VehicleId;
        if (!vehicleId) return null;

        const ratingUrl = `https://api.nhtsa.gov/SafetyRatings/VehicleId/${vehicleId}?format=json`;
        const ratingResponse = await fetch(ratingUrl);
        if (!ratingResponse.ok) return null;

        const ratingData = await ratingResponse.json();
        const ratings = ratingData.Results[0];
        if (!ratings) return null;

        return {
            overallRating: ratings.OverallRating || 'Not Rated',
            frontalCrash: ratings.FrontalCrashDriversideRating || 'Not Rated',
            sideCrash: ratings.SideCrashOverallRating || 'Not Rated',
            rollover: ratings.RolloverRating || 'Not Rated',
            reportUrl: `https://www.nhtsa.gov/vehicle/${year}/${encodeURIComponent(make)}/${encodeURIComponent(model)}`,
        };

    } catch (error) {
        console.error("NHTSA Safety Rating API Error:", error);
        return null;
    }
}


export const getVehicleReportByVin = (vin: string): Promise<VehicleReport> => {
  return new Promise((resolve, reject) => {
    // Keep a simulated delay to show loading indicator
    setTimeout(async () => {
      try {
        const upperVin = vin.toUpperCase();
        const { isValid, messageKey } = validateVin(upperVin);

        if (!isValid) {
          let errorMessage = 'The provided VIN is invalid. Please check and try again.';
          switch (messageKey) {
            case 'vinValidator.length':
              errorMessage = 'Invalid VIN format. A VIN must be 17 characters long.';
              break;
            case 'vinValidator.invalidChars':
              errorMessage = 'Invalid VIN format. The letters I, O, and Q are not used in VINs.';
              break;
            case 'vinValidator.nonAlphanumeric':
              errorMessage = 'Invalid VIN format. Only letters and numbers are allowed.';
              break;
            case 'vinValidator.checksum':
              errorMessage = 'Invalid VIN. The 9th character (check digit) is incorrect. Please verify the VIN.';
              break;
          }
          throw new Error(errorMessage);
        }
        
        const isExampleVin = !!MOCK_REPORTS_BY_VIN[upperVin];
        
        // Step 1: Decode VIN to get Year, Make, Model
        const decodedData = await decodeVinFromNhtsa(upperVin);

        // Step 2: Fetch recalls, safety ratings, complaints, and service bulletins in parallel
        const [recallData, safetyRatingData, complaintData, serviceBulletinData] = await Promise.all([
            getRecallsByVin(upperVin),
            getSafetyRatings(decodedData.year || 0, decodedData.make || '', decodedData.model || ''),
            getComplaintsByVin(upperVin),
            getServiceBulletinsByVin(upperVin),
        ]);
        
        const baseReport = MOCK_REPORTS_BY_VIN[upperVin] || createGenericReport(upperVin);

        const finalReport: VehicleReport = {
          ...baseReport,
          ...decodedData,
          vehicleSpecs: {
            ...baseReport.vehicleSpecs,
            ...decodedData.vehicleSpecs,
          },
          vin: decodedData.vin || baseReport.vin,
          year: decodedData.year || baseReport.year,
          make: decodedData.make || baseReport.make,
          model: decodedData.model || baseReport.model,
          decoded_at: new Date().toISOString(),
          // Use live data as the source of truth for non-example VINs
          recalls: isExampleVin ? baseReport.recalls : recallData,
          safetyRating: isExampleVin ? baseReport.safetyRating : safetyRatingData,
          complaints: isExampleVin ? baseReport.complaints : complaintData,
          serviceBulletins: isExampleVin ? baseReport.serviceBulletins : serviceBulletinData,
        };
        
        resolve(finalReport);
      } catch (err) {
        reject(err);
      }
    }, 1500);
  });
};