import React, { useState, useCallback, useEffect } from 'react';
import type { VehicleReport, SelectedPlan, UserSubscription } from './types';
import { getVehicleReportByVin } from './services/vinService';
import Header from './components/Header';
import Footer from './components/Footer';
import LandingPage from './components/LandingPage';
import ReportView from './components/ReportView';
import LoginPage from './components/LoginPage';
import SignUpPage from './components/SignUpPage';
import ForgotPasswordPage from './components/ForgotPasswordPage';
import ResetPasswordPage from './components/ResetPasswordPage';
import DealerPortal from './components/portal/DealerPortal';
import CheckoutPage from './components/checkout/CheckoutPage';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsAndConditions from './components/TermsAndConditions';
import { EXAMPLE_VINS, MOCK_DEALER_INVENTORY } from './constants';
import { plans } from './components/PricingTiers';
import LoadingIndicator from './components/LoadingIndicator';
import { useTranslation } from './i18n/useTranslation';

type AppView = 'landing' | 'login' | 'signup' | 'forgotPassword' | 'resetPassword' | 'portal' | 'checkout' | 'policy' | 'terms';

const App: React.FC = () => {
  const { t } = useTranslation();
  const [report, setReport] = useState<VehicleReport | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [vin, setVin] = useState<string>('');
  const [view, setView] = useState<AppView>('landing');
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [savedReports, setSavedReports] = useState<VehicleReport[]>(MOCK_DEALER_INVENTORY);
  const [selectedPlan, setSelectedPlan] = useState<SelectedPlan | null>(null);
  const [subscription, setSubscription] = useState<UserSubscription | null>(null);
  const [authMessage, setAuthMessage] = useState<string | null>(null);

  const handleSearch = useCallback(async (searchVin: string) => {
    setIsLoading(true);
    setError(null);
    setReport(null);
    setVin(searchVin);
    try {
      const data = await getVehicleReportByVin(searchVin);
      setReport(data);

      if (isLoggedIn) {
        setSavedReports(prevReports => {
            const existingReportIndex = prevReports.findIndex(r => r.vin === data.vin);
            if (existingReportIndex > -1) {
                const updatedReports = [...prevReports];
                updatedReports[existingReportIndex] = data;
                return updatedReports;
            } else {
                return [data, ...prevReports];
            }
        });
      }
      
      if (view !== 'portal') {
          setView('landing');
      }

    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [isLoggedIn, view]);

  useEffect(() => {
    const handleHashChange = () => {
        const hash = window.location.hash;
        if (hash.startsWith('#/report/')) {
            const vinFromHash = hash.substring('#/report/'.length);
            if (vinFromHash && report?.vin !== vinFromHash) {
                handleSearch(vinFromHash);
            }
        }
    };

    handleHashChange(); // Check hash on initial load

    window.addEventListener('hashchange', handleHashChange);

    return () => {
        window.removeEventListener('hashchange', handleHashChange);
    };
}, [handleSearch, report?.vin]);

  const handleReset = () => {
    setReport(null);
    setError(null);
    setIsLoading(false);
    setVin('');
    setView('landing');
    setSelectedPlan(null);
    setAuthMessage(null);
    if (window.location.hash) {
        window.history.pushState("", document.title, window.location.pathname + window.location.search);
    }
  };
  
  const handleLogin = () => {
    setIsLoggedIn(true);
    setAuthMessage(null);
    setSubscription({
        planName: 'Pro Dealer',
        billingCycle: 'monthly',
        status: 'active',
        nextBillingDate: 'October 31, 2024',
        reportsUsed: 27,
        reportsIncluded: 50,
        price: 39,
    });
    setView('portal');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setReport(null);
    setView('landing');
    setSubscription(null);
  };

  const handleBackToPortal = () => {
    setReport(null);
    setError(null);
    setIsLoading(false);
    setVin('');
    if (window.location.hash) {
        window.history.pushState("", document.title, window.location.pathname + window.location.search);
    }
    setView('portal');
  }

  const handleViewReport = (reportToView: VehicleReport) => {
    setReport(reportToView);
  }
  
  const handleViewPolicy = () => {
    setReport(null);
    setView('policy');
  };

  const handleViewTerms = () => {
    setReport(null);
    setView('terms');
  };

  const handlePortalClick = () => {
    setAuthMessage(null);
    if (isLoggedIn) {
      setReport(null);
      setView('portal');
    } else {
      setView('login');
    }
  };

  const handlePlanSelect = (plan: SelectedPlan) => {
    setSelectedPlan(plan);
    setView('checkout');
  };

  const handleGoToLogin = () => {
    setView('login');
    setAuthMessage(null);
  };

  const handleGoToSignUp = () => {
    setView('signup');
    setAuthMessage(null);
  };

  const handleGoToForgotPassword = () => {
    setView('forgotPassword');
    setAuthMessage(null);
  };
  
  const handleSignUp = () => {
      setView('login');
      setAuthMessage(t('loginPage.successMessage'));
  }
  
  const handleRequestReset = (email: string) => {
      console.log(`Password reset requested for ${email}`);
      setView('resetPassword');
      setAuthMessage(null);
  }
  
  const handlePasswordReset = () => {
      setView('login');
      setAuthMessage(t('loginPage.resetMessage'));
  }

  const scrollToSection = (sectionId: string) => {
    const action = () => {
      document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
    };

    if (report || view !== 'landing') {
      handleReset();
      setTimeout(action, 100); 
    } else {
      action();
    }
  };
  
  const renderContent = () => {
    if (view === 'signup') {
        return <SignUpPage onSignUp={handleSignUp} onBackToLogin={handleGoToLogin} />;
    }
    if (view === 'forgotPassword') {
        return <ForgotPasswordPage onRequestReset={handleRequestReset} onBackToLogin={handleGoToLogin} />;
    }
    if (view === 'resetPassword') {
        return <ResetPasswordPage onReset={handlePasswordReset} />;
    }
    if (view === 'login') {
      return <LoginPage onLogin={handleLogin} onBackToHome={handleReset} onSignUpClick={handleGoToSignUp} onForgotPasswordClick={handleGoToForgotPassword} message={authMessage} />;
    }
    
    if (view === 'checkout' && selectedPlan) {
      return <CheckoutPage plan={selectedPlan} onBack={handleReset} />;
    }
    
    if (view === 'policy') {
        return <PrivacyPolicy onBackToHome={handleReset} />;
    }
    
    if (view === 'terms') {
        return <TermsAndConditions onBackToHome={handleReset} />;
    }

    if (isLoading && !report && view !== 'portal') {
        return <LoadingIndicator />;
    }
    
    if (report && (view === 'landing' || window.location.hash.startsWith('#/report/'))) {
        const isExampleReport = EXAMPLE_VINS.some(v => v.vin === report.vin);
        const isFreePreview = !isLoggedIn && !isExampleReport;

        const handleUnlockSingleReport = () => {
            const singleReportPlan = plans.find(p => p.id === 'pay-as-you-go');
            if (singleReportPlan && typeof singleReportPlan.price === 'number') {
                handlePlanSelect({
                    name: singleReportPlan.name,
                    price: singleReportPlan.price,
                    billingCycle: 'monthly',
                    priceSuffix: t('pricingTiers.priceSuffixReport'),
                    features: singleReportPlan.features
                });
            }
        };

        const handleSubscribe = () => {
            const proPlan = plans.find(p => p.id === 'pro');
            if (proPlan) {
                handlePlanSelect({
                    name: proPlan.name,
                    price: proPlan.monthlyPrice,
                    billingCycle: 'monthly',
                    priceSuffix: t('pricingTiers.priceSuffixMonth'),
                    features: proPlan.features
                });
            }
        };

        return (
             <LandingPage
                onSearch={handleSearch}
                isLoading={isLoading}
                error={error}
                exampleVins={EXAMPLE_VINS}
                onSelectPlan={handlePlanSelect}
                activeReport={
                    <ReportView 
                        report={report} 
                        onNewSearch={handleReset}
                        isFreePreview={isFreePreview}
                        onUnlockReport={handleUnlockSingleReport}
                        onSubscribe={handleSubscribe}
                    />
                }
            />
        );
    }
    
    if (view === 'portal' && isLoggedIn) {
        if (report) {
            return (
                <ReportView 
                    report={report} 
                    onNewSearch={handleBackToPortal} 
                    newSearchText={t('reportView.backToPortal')}
                />
            )
        }
        return (
            <DealerPortal 
                onLogout={handleLogout} 
                onRunReport={handleSearch} 
                savedReports={savedReports} 
                onViewReport={handleViewReport} 
                subscription={subscription}
                setSubscription={setSubscription}
            />
        );
    }

    return (
        <LandingPage 
            onSearch={handleSearch}
            isLoading={isLoading}
            error={error}
            exampleVins={EXAMPLE_VINS}
            onSelectPlan={handlePlanSelect}
        />
    );
  };
  
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header 
        isLoggedIn={isLoggedIn} 
        onLogoClick={handleReset} 
        onFeaturesClick={() => scrollToSection('features')}
        onPricingClick={() => scrollToSection('pricing')}
        onPortalClick={handlePortalClick}
        onSignInClick={handleGoToLogin}
        onLogoutClick={handleLogout}
      />
      <main className="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 print:p-0 print:m-0 print:max-w-full">
        {renderContent()}
      </main>
      <Footer onPolicyClick={handleViewPolicy} onTermsClick={handleViewTerms} />
    </div>
  );
};

export default App;