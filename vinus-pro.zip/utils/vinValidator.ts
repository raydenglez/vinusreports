const VIN_TRANSLITERATION: { [key: string]: number } = {
  'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7, 'H': 8,
  'J': 1, 'K': 2, 'L': 3, 'M': 4, 'N': 5, 'P': 7, 'R': 9,
  'S': 2, 'T': 3, 'U': 4, 'V': 5, 'W': 6, 'X': 7, 'Y': 8, 'Z': 9
};

const VIN_WEIGHTS = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2];

export const validateVin = (vin: string): { isValid: boolean; messageKey: string; suggestion?: string; options?: Record<string, string> } => {
    const upperVin = vin.toUpperCase();
    
    if (upperVin.length !== 17) {
        return { isValid: false, messageKey: 'vinValidator.length' };
    }
    if (/[IOQ]/.test(upperVin)) {
        return { isValid: false, messageKey: 'vinValidator.invalidChars' };
    }
    if (!/^[A-HJ-NPR-Z0-9]{17}$/.test(upperVin)) {
        return { isValid: false, messageKey: 'vinValidator.nonAlphanumeric' };
    }

    let sum = 0;
    for (let i = 0; i < 17; i++) {
        const char = upperVin[i];
        const value = isNaN(parseInt(char)) ? VIN_TRANSLITERATION[char] : parseInt(char);
        if (value === undefined) {
             return { isValid: false, messageKey: 'vinValidator.invalidChar', options: { char } };
        }
        sum += value * VIN_WEIGHTS[i];
    }

    const checkDigit = sum % 11;
    const actualCheckDigit = upperVin[8];
    
    const expectedCheckDigit = checkDigit === 10 ? 'X' : String(checkDigit);

    if (actualCheckDigit !== expectedCheckDigit) {
         return { isValid: false, messageKey: 'vinValidator.checksum' };
    }
    
    let suggestion = upperVin;
    let madeSuggestion = false;
    suggestion = suggestion.replace(/S/g, '5');
    suggestion = suggestion.replace(/B/g, '8');
    if (suggestion !== upperVin) {
        const { isValid: isSuggestionValid } = validateVin(suggestion);
        if (isSuggestionValid) {
            return { isValid: true, messageKey: 'vinValidator.valid', suggestion: suggestion };
        }
    }

    return { isValid: true, messageKey: 'vinValidator.valid' };
};
